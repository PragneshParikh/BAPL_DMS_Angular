# Backend and web findings (no changes made)

Found while mapping the Angular app to `DMSBAPLAPI`. Nothing below was changed; each item needs an owner decision.

| # | Finding | Evidence | Impact | Minimum fix (proposal) |
|---|---|---|---|---|
| 1 | Password-reset e-mail link points to `https://yourdomain.com` outside Development | `AuthController.ForgotPassword`: `baseUrl = _env.IsDevelopment() ? "http://localhost:4200" : "https://yourdomain.com"` | Reset links from production e-mails do not open the DMS | Read the web base URL from configuration (e.g. `App:WebBaseUrl`) |
| 2 | Web circular upload never completes | `dialogs/add-circular/add-circular.ts uploadFile()`: Blob upload commented out, promise never resolved | Admins cannot add PDF attachments from the web | Web: send base64 `fileData` (as the app does), or finish the SAS upload and store `FilePath` |
| 3 | 48 Angular calls have no matching action in DMSBAPLAPI | `api_endpoints.csv`, status "NOT FOUND" | Those web features fail today; they will be ported only after confirmation | Review list; examples below |
| 3a | `GET Employee/menu-preview`, `GET chassis-details/battery-serials/{chassisNo}` | not in any controller | — | Remove from web or add endpoint |
| 3b | `GET WarrantyJobCardClaim/GetPendingWarrantyJCClaims`, `PUT WarrantyPacking/UpdateWarrantyPackingSlip`, `GET WarrantyDispatch/GetWarrantyDispatchById` | not in controllers | Warranty flows partially broken | Confirm intended actions |
| 3c | `EbwReport` + `/api/dispatch/*` (EBW notifications/serials) | not in DMSBAPLAPI | Probably a different service | Confirm host |
| 3d | `POST {ERPApiUrl}/BAPLregistration` | ERP API, called from the browser | Needs ERP access from the app as well | Confirm ERP URL per environment and auth |
| 4 | No refresh-token endpoint | AuthController | Users are logged out when the 24 h JWT expires (same on web and app) | Optional: refresh endpoint |
| 5 | `GET circular/GetByDealerCode/{dealerCode}` receives the literal string `"null"` for SuperAdmin | `CircularController` converts `"null"` to null | Works, but fragile | Optional query parameter |
| 6 | Template leftovers in Angular (`rest-api.service.ts`, NgRx e-commerce/crypto stores, `core/data/*`) | app.config.ts | None for the app; adds bundle weight on web | Remove from web when convenient |

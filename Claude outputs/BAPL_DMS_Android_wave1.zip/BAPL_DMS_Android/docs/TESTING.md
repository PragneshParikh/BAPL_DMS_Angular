# Testing

## 1. What has been verified so far

| Check | Result | How |
|---|---|---|
| Business rules ported from Angular (guard, bitmask rights, Indian number/date format, FY ranges, JWT expiry) | 31/31 assertions passed | Compiled and run with Kotlin 2.0.21 on JVM (`app/src/test/.../BusinessRulesTest.kt` holds the same cases as JUnit tests) |
| Kotlin syntax of all 44 source files | No syntax errors | Kotlin compiler parse pass |
| Full Android compile, lint, APK | **Not yet run** | Requires Android SDK + Google Maven, not reachable from the build environment |
| Live API calls | **Not yet run** | Needs a device/emulator with network and a test user |

Run unit tests: `gradlew.bat testDebugUnitTest`.

## 2. Manual test script (run on device/emulator after the first build)

Use test accounts for each role: SuperAdmin, Dealer, Location Login (one location and multi-location), BG employee.

| # | Scenario | Steps | Expected |
|---|---|---|---|
| A1 | Login – empty fields | Tap Sign In | "Username is required", "Password is required" |
| A2 | Login – wrong password | Valid user, wrong password | Snackbar "Invalid password." |
| A3 | Login – dealer | Dealer credentials | Dashboard opens; drawer shows the dealer's menu only |
| A4 | Login – multi-location | Location Login ID linked to 2+ locations | Location list appears; picking one logs in; drawer header shows the location |
| A5 | Session restore | Log in, close app, reopen | Opens on Dashboard without login |
| A6 | Token expiry / 401 | Wait for expiry or revoke token | Returned to login with "Your session has expired…" |
| A7 | Logout | Top-bar logout → confirm | Login screen; reopening app asks for login |
| A8 | Forgot password | Enter registered e-mail | "Password reset link sent." |
| A9 | Reset password | Paste e-mail link, enter matching passwords | Success → login screen |
| N1 | Module switch | Drawer → WorkShop | Menu shows only WorkShop items; Dashboard opens |
| N2 | Page guard | Dealer without right to an item (if the API lists it) | "Access denied" dialog |
| N3 | Not-converted item | Open e.g. Job Card | "Not yet available in the Android app" with web route |
| D1 | Dashboard figures | Compare KPIs with web dashboard for same FY | Units, sales value, stock, job cards match |
| D2 | Date filter | Select FY 2025-26, then custom dates | Figures reload; range label DD.MM.YYYY |
| D3 | Drill-down | Tap a KPI | Opens target (currently not-converted screen for reports) |
| C1 | Circular browse | Circular menu → Category → Year → Month → Date | Circulars for that date with attachments |
| C2 | PDF preview | Tap an attachment | Pages render; Download saves to Downloads/BGauss DMS; Open with / Share work |
| C3 | Add circular (SuperAdmin) | Add → category, date, title, pick PDF → Save | "Files uploaded successfully."; appears in tree; same in web |
| C4 | Duplicate date rule | Pick a date that already has a circular in that category | Warning; date cleared |
| C5 | Non-PDF file | Pick a .docx | "Only PDF files are allowed." |
| C6 | Edit / remove attachment | Edit → remove a file → Save | "Records updated successfully."; file gone |
| C7 | Dealer permissions | Configure → zone → tick dealers → Save | "Dealer permissions updated successfully."; dealer login now sees it |
| C8 | Dealer view | Log in as dealer | Only assigned circulars; no Add/Edit/Configure |
| E1 | Offline | Airplane mode, open dashboard/circular | "You're offline" with Retry |
| E2 | Rotation / dark mode | Rotate, switch dark theme | No data loss; readable UI |

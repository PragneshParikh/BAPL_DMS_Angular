# Module status

Updated: 03.11.2026 · Build status: **written, not yet compiled** (no Android SDK/Maven access in the build environment; first build to be run in Android Studio).

Full per-route list: `module_mapping.csv` (178 web routes). Full API list: `api_endpoints.csv` (598 calls).

## Completed – Wave 0 (foundation) and Wave 1 part 1

| Area | Web source | Android | API |
|---|---|---|---|
| Login (username/e-mail/Location Login ID) | account/login | `LoginScreen` | POST auth |
| Multi-location Location Login | AuthController step 2 | Location picker dialog | POST auth/location-login |
| Forgot password | account/forgot-password | `ForgotPasswordScreen` | POST auth/forgot-password |
| Reset password | account/reset-password | `ResetPasswordScreen` (paste link or `bapldms://` link) | POST auth/reset-password |
| Session, token, expiry, 401 logout | auth.service, interceptors | `SessionManager`, `AuthInterceptor`, `UnauthorizedInterceptor` | — |
| Page guard + button rights | auth.guard, menu-access.service | `AccessControl` | GET role-wise-menu/GetByRoleId |
| Sidebar + module switch | layouts/sidebar, topbar | `HomeScreen` drawer (server menu), ShowRoom/WorkShop/Account | GET menu |
| Dashboard | components/dashboard | `DashboardScreen` (KPIs, sales vs stock, stock by model, top dealers, payment mix, job status, FY/date filter) | GET Report/total-sale-dealer-wise, model-wise-sale-count, model-wise-stock-count, job-card/summary-stats |
| Circulars (documents) | components/circular, dialogs/add-circular, dialogs/circular-permission | `CircularScreen`, `CircularEditorScreen`, `CircularPermissionScreen`, `PdfViewerScreen` | circular/*, circular-dealer-assignment/* |
| Document handling | — | System picker (PDF), base64 upload, in-app PDF render, Downloads, open-with, share | — |

Every other menu entry is shown in the drawer exactly as on the web and opens a "not yet available in the app" screen (the web app's WorkInProgress equivalent). No data is faked.

## Behaviour differences from the web (deliberate, please confirm)

| # | Web | Android | Reason |
|---|---|---|---|
| 1 | Multi-location Location Login shows "contact your admin" | User picks the location | API already supports it (`locationCode` in location-login) |
| 2 | Circular upload goes through an Azure SAS step whose upload code is commented out, so new files never save | PDF sent as base64 `fileData`, which `CircularController.Create/Update` stores | Makes the feature work without backend change |
| 3 | Reset password accepts mismatched confirmation | Blocks mismatch | Backend ignores ConfirmPassword; prevents a wrong password being set |
| 4 | Forgot password with unknown e-mail: empty response, web shows nothing | Neutral "If this e-mail is registered…" message | Does not reveal which e-mails exist |
| 5 | Dashboard charts (ApexCharts) | Native bar/progress visuals, same figures and drill-down links | No chart library dependency |

## Pending (planned waves)

| Wave | Modules (web routes) |
|---|---|
| 1 part 2 | Chassis search, Customer ledger, read-only reports (17), analytics pages (dealer/sales/stock/workshop/account) |
| 2 – Sales | Vehicle PO, Lot inspection, Vehicle sale bill (+ proforma, Form 22, delivery certificate/checklist/slip, sale letter), Receipt entry, Quotation, Stock transfer, HSRP order/inward, Open stock, Repo billing, Vehicle sale/dispatch import, Vehicle/part invoice dispatch |
| 3 – Workshop | Job card, Estimate, Repair bill (+ proforma/invoice), Counter bill, Labour masters, PDI checklist, service masters, Vehicle info update |
| 4 – Parts & Warranty | Parts PO, Parts inward, Material transfer, Kit creation, Stock adjustment, FFIR, Warranty JC claim/order/invoice/packaging/dispatch, UW line items, Free service claim/rate, OEM model warranty, EBW invoice/report, Warranty register |
| 5 – Masters & Admin | Dealer/location/colour/city/OEM/HSN/tax/group/occupation/T&C/dispatch masters, employee & BG employee, roles, rights, dealer creation manager, prefix, API tracking, Who-am-I |

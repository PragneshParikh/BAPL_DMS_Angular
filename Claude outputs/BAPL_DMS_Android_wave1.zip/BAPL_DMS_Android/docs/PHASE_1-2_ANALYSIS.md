# BAPL DMS → Android: Phase 1–2 Analysis

Prepared: 03.11.2026 · Source: `BAPL_DMS_Angular` (Angular 20, standalone) and `DMSBAPLAPI` (.NET, EF Core, SQL Server). Neither project was modified.

Companion files: `module_mapping.csv` (178 routes → component → service → controller → Android status) and `api_endpoints.csv` (598 Angular API calls matched to backend actions).

---

## 1. Headline findings

| # | Finding | Type | Impact |
|---|---|---|---|
| 1 | "DMS" is a **Dealer Management System** (vehicle sales, workshop, parts, warranty, HSRP, ERP sync), not a Document Management System. Only **Circulars** handle documents (PDF stored as base64, category/year/month tree, dealer assignment). | Fact | The brief's document-centric items (upload/preview/approval/versioning) map to Circulars, Excel imports/exports and printable PDFs — not a generic document repository. |
| 2 | Scale: **95 component folders, 178 routes, 99 Angular service files, 95 API controllers, 639 backend endpoints**; 3.6 MB of component source. Largest screens: Repair Bill (87 KB TS + 56 KB HTML), Warranty Order, Vehicle Sale Bill, Job Card. | Fact | Full parity is a multi-month build. It must be delivered in waves. |
| 3 | APK cannot be built in this cloud environment: Google Maven, Maven Central and Gradle distribution hosts are blocked (proxy 403). No shell is available on your PC either. | Fact | I can write the full Android Studio project, but compilation and the debug APK must be run on your machine (Android Studio → Build → Build APK). I cannot claim "compiles successfully" until you run it. |
| 4 | Navigation and permissions are **server-driven**: `GET /api/menu` (sidebar), `GET /api/menu/my-access` (Location Login roles), `GET /api/menu-rights/{dealerCode}` (bitmask rights). Each route carries a `subMenuId`. | Fact | Android navigation drawer should be built from the same API, not hard-coded. |
| 5 | 48 Angular calls have **no matching action in DMSBAPLAPI** (see `api_endpoints.csv`, status "NOT FOUND"). Some target other services (ERP `BAPLregistration`, `/api/dispatch/*` for EBW); others look like dead/stale calls (`Employee/menu-preview`, `chassis-details/battery-serials`, `WarrantyJobCardClaim/GetPendingWarrantyJCClaims`, `WarrantyPacking/UpdateWarrantyPackingSlip`, `WarrantyDispatch/GetWarrantyDispatchById`, `Report/colour-wise`). | Fact + Interpretation | These screens will fail the same way on Android. Each needs confirmation before porting. |
| 6 | No refresh-token endpoint. JWT expiry = forced logout (Angular sets a timer from the `exp` claim). | Fact | Android will mirror this: decode `exp`, logout on expiry or any 401. |

---

## 2. Architecture (as-is)

### 2.1 Angular frontend
- Angular 20 standalone components, Bootstrap/NgBootstrap (Velzon admin template), ApexCharts, ngx-translate. NgRx store is template leftover (e-commerce/crypto demo effects) — not used by DMS screens.
- `rest-api.service.ts`, `core/data/*` = template demo code. **Excluded** from conversion.
- Environments: dev `http://localhost:5215/api`; prod `https://bapldmsai-…azurewebsites.net/api`; separate `ERPApiUrl` (UAT ERP) called directly by the browser for `BAPLregistration`.

### 2.2 Authentication & session
| Item | Behaviour (source) |
|---|---|
| Login | `POST /api/auth` `{username, password}` → `{userId, email, userName, dealerCode, employeeCode, mappedZones, token, role, roles[], compName, status:"success"}`. Username may be email, AspNetUsers user, or a **Location Login ID** (backend tries all). |
| Location Login | `POST /api/auth/location-login` `{locationLoginId, password, locationCode?}`; may return `requiresLocationSelection` with location list; success adds `locationCode`, `locationRoleId`. |
| Forgot / reset | `POST /api/auth/forgot-password` `{email}`; `POST /api/auth/reset-password` `{email, token, password, confirmPassword}`. |
| Header | `Authorization: Bearer <token>` (functional interceptor). |
| Storage | localStorage: `token`, `currentUser` (base64 JSON), `role`, `dealerCode`, `locationCode`, `locationRoleId`, `menuRights`, `selectedModule`. |
| Expiry | Timer from JWT `exp` → logout. 401 → logout (error interceptor). |
| SuperAdmin tools | Impersonate, admin password reset, location password reset, impersonation log (`[Authorize(Roles="SuperAdmin")]`). |

### 2.3 Authorisation model
- **Route guard**: SuperAdmin/Admin → all pages. Others → `menuRights.find(subMenuId).permission > 0`.
- **Button-level** (`MenuAccessService`), applies **only to role = Dealer**: bitmask View 1, Create 2, Edit 4, Delete 8, Download 16. Dealer with no rights configured = fail-open (sees everything).
- Module switch (`selectedModule`, default `ShowRoom`) filters the sidebar.

### 2.4 Backend
- ASP.NET Core, JWT bearer, Identity, EF Core (`BapldmsvadContext`), QuestPDF for server PDFs, Azure Blob SAS (`GET /api/files/generate-upload-url?fileName=`), ExcelImport/Export endpoints, middleware for authorisation, API audit, exceptions.
- CORS `AllowAnyOrigin` — no change needed for a native app (CORS does not apply).
- Two outbound HTTP clients (TSM, ERP).

### 2.5 Document-type features found
| Feature | Where | Android approach |
|---|---|---|
| Circular PDF upload/view, category/year/month browse, dealer assignment | Circular, CircularAttachment, CircularDealerAssignment | System document picker → base64 → same API; view via cached file + PDF renderer / external intent |
| Excel import (dealers, chassis, tax codes, labour, vehicle sale/dispatch, stock adjustment) | ~12 `import` endpoints, multipart `IFormFile` | Document picker + Retrofit multipart |
| Excel export / download | ~30 `download`/`export` endpoints (blob) | Streaming download to Downloads via MediaStore, open with intent |
| Server PDFs (sale bill, Form 22, combined) | `VehicleSaleBill/Download*` | Same download path |
| Client-side print screens (delivery certificate/checklist/slip, sale letter, proforma, Form 22 cert, counter bill print, repair bill proforma/invoice, job card print) | Angular HTML templates | Rebuild as on-device PDF (Android `PdfDocument`) or WebView print — **per-template effort** |
| Approval workflows | Warranty order → invoice → packaging → dispatch; FFIR; lot inspection accept; PO submit to ERP; sale bill confirm/send to ERP | Status-driven list/detail screens |
| Version management | **Not present** in source | Not implemented (no backend support) |

---

## 3. Module inventory (178 routes)

| Area | Routes | Key screens |
|---|---|---|
| Authentication | 3 | Login, Forgot password, Reset password |
| Dashboard & Reports | 26 | Dashboard, Dealer/Sales/Stock/Workshop/Account analytics, 17 reports |
| Sales / Showroom | 39 | Vehicle PO, Lot inspection, Sale bill (+ proforma, Form 22, delivery docs, sale letter), Receipt entry, Quotation, Stock transfer, HSRP order/inward, Customer ledger, Chassis search, Open stock, Repo billing, Vehicle sale/dispatch import |
| Workshop / Service | 24 | Job card, Estimate, Repair bill (+ proforma/invoice), Counter bill, Labour masters, PDI checklist, Service masters, Vehicle info update |
| Parts & Inventory | 11 | Parts PO, Parts inward, Material transfer, Kit creation, Item master (spares), Part invoice dispatch |
| Warranty & Claims | 27 | FFIR, Warranty JC claim, Warranty order/invoice/packaging/dispatch, UW line items, Free service claim/rate, OEM model warranty, EBW invoice, Warranty register |
| Masters | 19 | Dealer, Location, Color, City, OEM model, Battery capacity, HSN, Tax code, Aggregate tax, HSN-wise tax, Group, Occupation, T&C, Dispatch, Dealer account, Bulk upload |
| Admin & Access Control | 28 | Employee, BG employee, Role, BG role, Dept, Designation, Role menu rights, Menu right, Dealer creation manager, Dealer menu access, Location edit, Prefix, Who-am-I, API tracking, Access control |
| Circulars | 1 | Circular |

Full list with `subMenuId`, Angular file, services and controllers: `module_mapping.csv`. Service links marked `source` were read from component imports; `inferred` were matched by name and will be confirmed when each module is built.

---

## 4. Proposed Android architecture

- Kotlin, Jetpack Compose (Material 3), MVVM + use cases, Hilt, Retrofit + OkHttp + kotlinx.serialization, DataStore (encrypted token via Android Keystore), Coroutines/Flow, Navigation Compose, Paging 3 for paged lists, Vico for charts.
- `data/api` one Retrofit interface per backend controller; `AuthInterceptor` (Bearer), `UnauthorizedInterceptor` (401 → session end), `ApiResult` wrapper for loading/success/error/network states.
- Base URLs (`API_BASE_URL`, `ERP_API_BASE_URL`) per build type in `BuildConfig`, sourced from `local.properties`/Gradle properties — not hard-coded in Kotlin.
- Navigation drawer generated from `/api/menu` + rights; route registry maps `subMenuId` → Compose destination; permission checks reuse the exact guard + bitmask rules above.
- Reusable components: searchable dropdown, date-range filter, paged list with search, form fields with validation, confirm dialog, file picker, download/open, empty/error states.

---

## 5. Delivery plan (waves)

| Wave | Scope | Notes |
|---|---|---|
| 0 | Project setup, auth (login, location login, forgot/reset), session/expiry, dynamic drawer, permissions, dashboard shell | Foundation for everything else |
| 1 | Circulars (documents), Chassis search, Customer ledger, Reports (read-only) | Highest mobile value, lowest risk |
| 2 | Sales: Vehicle PO, Lot inspection, Sale bill + documents, Receipt entry, Quotation, Stock transfer, HSRP | Heaviest business logic |
| 3 | Workshop: Job card, Estimate, Repair bill, Counter bill | Largest forms |
| 4 | Parts & Warranty flows | Multi-step approvals |
| 5 | Masters & Admin | Low mobile value; candidates to defer |

---

## 6. Risks and open points

| Risk | Impact | Proposed handling |
|---|---|---|
| No build environment here | Compile errors surface only on your machine | You build after each wave and share errors; I fix |
| 48 unmatched API calls | Broken screens in both web and app | Confirm per module; document, do not invent |
| Large desktop forms (40–60 fields, line-item grids) | Poor mobile UX if copied 1:1 | Stepper/sectioned forms, bottom-sheet line-item editors |
| Client-side print templates | Each needs re-implementation | Prioritise those used in the field (delivery docs, job card) |
| Admin/Master screens on mobile | Effort with little field use | Recommend deferring to web unless required |
| `appsettings.json` not read | — | Not needed; no secrets copied into the app |

# BGauss DMS – Android

Native Android client for the BAPL Dealer Management System. It talks to the existing
`DMSBAPLAPI` backend (no backend changes) and mirrors the Angular web app's rules.

Stack: Kotlin 2.1 · Jetpack Compose (Material 3) · MVVM · Hilt · Retrofit/OkHttp ·
kotlinx.serialization · DataStore (Keystore-encrypted session) · Coroutines/Flow · Navigation Compose.
minSdk 26 (Android 8.0), target/compile SDK 35.

## Build the debug APK (Android Studio)

1. Install Android Studio (Ladybug 2024.2 or newer) with Android SDK 35 and JDK 17 (bundled JBR is fine).
2. File → Open → select this `BAPL_DMS_Android` folder. Let Gradle sync finish (first sync downloads
   Gradle 8.11.1 and the dependencies listed in `gradle/libs.versions.toml`).
3. Build → Build App Bundle(s)/APK(s) → **Build APK(s)**.
4. Output: `app/build/outputs/apk/debug/app-debug.apk` (application id `com.bgauss.dms.debug`).

Command line alternative (from this folder): `gradlew.bat assembleDebug` (Windows) or
`./gradlew assembleDebug`. Unit tests: `gradlew.bat testDebugUnitTest`.

If the build fails, send the first error block from the **Build** window – the project was written
in an environment without access to Google Maven, so it has not been compiled yet.

## API endpoint configuration

Base URLs are Gradle properties (same values as Angular `environment.prod.ts`), not hard-coded in Kotlin:

| Property | Default |
|---|---|
| `bapl.apiBaseUrl` | `https://bapldmsai-e6f0hzhmg4achue9.centralindia-01.azurewebsites.net/api/` |
| `bapl.erpApiBaseUrl` | `https://uatbaplai-cpapc4h7gvdkfxh4.centralindia-01.azurewebsites.net/api/` (not used yet) |

Override without editing the project: add the property to `%USERPROFILE%\.gradle\gradle.properties`,
or pass `-Pbapl.apiBaseUrl=http://10.0.2.2:5215/api/` to target a local API from the emulator
(cleartext is allowed for `10.0.2.2` only).

## Project layout

```
app/src/main/java/com/bgauss/dms/
  core/        network (ApiResult, safeApiCall, interceptors), session (JWT, encrypted session),
               security (Keystore cipher), permission (guard + bitmask rules), util (formatters, files)
  data/        api (Retrofit interfaces per controller), model (DTOs), repository
  di/          Hilt modules
  presentation/
    auth/        Login, Location selection, Forgot/Reset password
    main/        Home shell: server-driven drawer, module switch (ShowRoom/WorkShop/Account), logout
    dashboard/   KPI dashboard (same Report APIs as web)
    circular/    Circulars (document library): browse, PDF preview, add/edit, dealer permissions
    document/    In-app PDF viewer, download, open-with, share
    navigation/  Root + Home nav graphs, route registry, Angular route table (subMenuIds)
    wip/         "Not yet converted" screen for menu items still on the web
docs/          Analysis, module mapping, API mapping, status, testing, backend findings
```

See `docs/MODULE_STATUS.md` for what is done and what is pending.

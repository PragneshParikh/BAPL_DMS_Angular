package com.bgauss.dms.core.session

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.util.Base64

/**
 * Minimal JWT payload reader. Mirrors AuthenticationService.startTokenTimer() in Angular:
 * only the `exp` claim is used, to log the user out exactly when the token expires.
 * The signature is not verified on the device – the API does that on every request.
 */
object Jwt {

    /** Expiry as epoch milliseconds, or null if the token is malformed or has no `exp`. */
    fun expiryEpochMillis(token: String): Long? {
        val parts = token.split('.')
        if (parts.size < 2) return null
        return try {
            val payload = String(Base64.getUrlDecoder().decode(padBase64(parts[1])), Charsets.UTF_8)
            val obj = Json.parseToJsonElement(payload) as? JsonObject ?: return null
            val exp = (obj["exp"] as? JsonPrimitive)?.longOrNull ?: return null
            exp * 1000L
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    fun isExpired(token: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val exp = expiryEpochMillis(token) ?: return true
        return exp <= nowMillis
    }

    private fun padBase64(segment: String): String {
        val rem = segment.length % 4
        return if (rem == 0) segment else segment + "=".repeat(4 - rem)
    }
}

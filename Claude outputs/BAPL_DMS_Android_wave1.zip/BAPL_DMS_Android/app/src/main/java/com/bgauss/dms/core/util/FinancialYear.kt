package com.bgauss.dms.core.util

import java.time.LocalDate

/**
 * Indian financial-year helpers, ported from components/dashboard/dashboard-kit.ts
 * (defaultRange, fyOptions). FY = 1 Apr – 31 Mar; first FY offered is 2020-21.
 */
object FinancialYear {
    const val FIRST_FY = 2020
    val DEFAULT_FROM: LocalDate = LocalDate.of(2020, 1, 1)

    data class Option(val key: String, val label: String, val from: LocalDate, val to: LocalDate)

    /** Default dashboard range: 01.01.2020 – today. */
    fun defaultRange(today: LocalDate = LocalDate.now()): Pair<LocalDate, LocalDate> = DEFAULT_FROM to today

    /** Newest first; the current FY ends today. */
    fun options(today: LocalDate = LocalDate.now()): List<Option> {
        val current = if (today.monthValue >= 4) today.year else today.year - 1
        return (current downTo FIRST_FY).map { y ->
            val end = LocalDate.of(y + 1, 3, 31)
            Option(
                key = y.toString(),
                label = "FY $y-${(y + 1).toString().takeLast(2)}",
                from = LocalDate.of(y, 4, 1),
                to = if (end.isBefore(today)) end else today,
            )
        }
    }
}

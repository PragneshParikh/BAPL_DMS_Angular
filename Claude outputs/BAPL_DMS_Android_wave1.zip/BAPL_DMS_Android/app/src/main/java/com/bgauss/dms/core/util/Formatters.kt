package com.bgauss.dms.core.util

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale

/** Formatting rules shared by all screens: DD.MM.YYYY dates and Indian (lakh/crore) grouping. */
object Formatters {

    private val displayDate: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    private val displayDateTime: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy hh:mm a", Locale.ENGLISH)
    val isoDate: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    /** Whole number with Indian grouping, e.g. 12,34,567. "—" for null, like dashboard-kit num(). */
    fun number(value: Number?): String {
        if (value == null) return "—"
        val d = value.toDouble()
        if (d.isNaN()) return "—"
        return groupIndian(Math.round(d))
    }

    /**
     * Lakh/crore grouping done by hand so the output is identical on every device/JVM
     * (java.text NumberFormat does not group en-IN as 12,34,567 everywhere).
     */
    fun groupIndian(n: Long): String {
        val negative = n < 0
        val digits = kotlin.math.abs(n).toString()
        if (digits.length <= 3) return (if (negative) "-" else "") + digits
        val last3 = digits.takeLast(3)
        val rest = digits.dropLast(3)
        val groups = rest.reversed().chunked(2).joinToString(",") { it.reversed() }.split(",").reversed().joinToString(",")
        return (if (negative) "-" else "") + groups + "," + last3
    }

    /** Same thresholds as dashboard-kit inr(): ≥1 Cr → "₹x.xx Cr", ≥1 L → "₹x.xx L", else ₹ grouped. */
    fun inrCompact(value: Number?): String {
        if (value == null) return "—"
        val v = value.toDouble()
        if (v.isNaN()) return "—"
        val abs = kotlin.math.abs(v)
        return when {
            abs >= 1e7 -> "₹" + String.format(Locale.ENGLISH, "%.2f", v / 1e7) + " Cr"
            abs >= 1e5 -> "₹" + String.format(Locale.ENGLISH, "%.2f", v / 1e5) + " L"
            else -> "₹" + number(v)
        }
    }

    /** Full rupee amount with paise, Indian grouping: ₹1,23,456.78 */
    fun inr(value: Number?): String {
        if (value == null) return "—"
        val d = value.toDouble()
        if (d.isNaN()) return "—"
        val paise = Math.round(kotlin.math.abs(d) * 100)
        val sign = if (d < 0) "-" else ""
        return "$sign₹" + groupIndian(paise / 100) + "." + (paise % 100).toString().padStart(2, '0')
    }

    fun date(value: LocalDate?): String = value?.format(displayDate) ?: "—"

    /**
     * Parses the date strings the API sends ("2026-11-03", "2026-11-03T10:15:00",
     * "2026-11-03T10:15:00.123Z", "03-11-2026") and prints DD.MM.YYYY.
     * Returns the raw value if it cannot be parsed, so nothing is silently lost.
     */
    fun apiDate(raw: String?): String {
        if (raw.isNullOrBlank()) return "—"
        return parseApiDate(raw)?.format(displayDate) ?: raw
    }

    fun apiDateTime(raw: String?): String {
        if (raw.isNullOrBlank()) return "—"
        parseApiDateTime(raw)?.let { return it.format(displayDateTime) }
        return apiDate(raw)
    }

    fun parseApiDate(raw: String): LocalDate? {
        val s = raw.trim()
        runCatching { return LocalDate.parse(s.take(10)) }
        runCatching { return LocalDate.parse(s, DateTimeFormatter.ofPattern("dd-MM-yyyy")) }
        runCatching { return LocalDate.parse(s, DateTimeFormatter.ofPattern("dd/MM/yyyy")) }
        return null
    }

    private fun parseApiDateTime(raw: String): LocalDateTime? {
        val s = raw.trim()
        if (s.length <= 10) return null
        return try {
            OffsetDateTime.parse(s).toLocalDateTime()
        } catch (e: DateTimeParseException) {
            try {
                LocalDateTime.parse(s.substringBefore('Z'))
            } catch (e2: DateTimeParseException) {
                null
            }
        }
    }

    /** "2026-04-01".."2026-11-03" → "01.04.2026 – 03.11.2026" (dashboard-kit fmtRange). */
    fun range(from: LocalDate, to: LocalDate): String = "${date(from)} – ${date(to)}"
}

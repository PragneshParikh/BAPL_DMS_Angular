package com.bgauss.dms.presentation.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.permission.AccessControl
import com.bgauss.dms.core.session.AppModule
import com.bgauss.dms.core.session.SessionManager
import com.bgauss.dms.core.session.SessionState
import com.bgauss.dms.core.session.UserSession
import com.bgauss.dms.data.repository.AuthRepository
import com.bgauss.dms.data.repository.MenuNode
import com.bgauss.dms.data.repository.MenuRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val session: UserSession? = null,
    val module: AppModule = AppModule.ShowRoom,
    val menu: List<MenuNode> = emptyList(),
    val menuLoading: Boolean = true,
    val menuError: ApiResult.Failure? = null,
) {
    val access: AccessControl get() = session?.accessControl ?: AccessControl.NONE
}

/**
 * State of the logged-in shell: user header, module switch (topbar onSelectionChange),
 * and the server-driven drawer (sidebar getMasterMenu + filterMenuByModule).
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val sessionManager: SessionManager,
    private val menuRepository: MenuRepository,
    private val authRepository: AuthRepository,
) : ViewModel() {

    private val rawMenu = MutableStateFlow<List<MenuNode>>(emptyList())
    private val loading = MutableStateFlow(true)
    private val error = MutableStateFlow<ApiResult.Failure?>(null)

    private val session = sessionManager.state.map { (it as? SessionState.LoggedIn)?.session }

    val state: StateFlow<HomeUiState> = combine(session, rawMenu, loading, error) { s, menu, isLoading, err ->
        val module = AppModule.fromKey(s?.selectedModule)
        HomeUiState(
            session = s,
            module = module,
            menu = MenuRepository.filterByModule(menu, module.key),
            menuLoading = isLoading,
            menuError = err,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    init {
        reloadMenu()
    }

    fun reloadMenu() {
        viewModelScope.launch {
            loading.value = true
            error.value = null
            when (val r = menuRepository.loadMenu()) {
                is ApiResult.Success -> rawMenu.value = r.data
                is ApiResult.Failure -> error.value = r
            }
            // Keep page/button rights current, as the web sidebar does on every load.
            authRepository.refreshMenuRights()
            loading.value = false
        }
    }

    fun selectModule(module: AppModule) {
        viewModelScope.launch { sessionManager.update { it.copy(selectedModule = module.key) } }
    }

    fun logout() = authRepository.logout()
}

package com.bgauss.dms.data.api

import com.bgauss.dms.data.model.CircularDealerAssignmentDto
import com.bgauss.dms.data.model.CircularDto
import com.bgauss.dms.data.model.CircularFolderTree
import com.bgauss.dms.data.model.ForgotPasswordRequest
import com.bgauss.dms.data.model.JobReportSummaryStats
import com.bgauss.dms.data.model.LocationLoginRequest
import com.bgauss.dms.data.model.LoginRequest
import com.bgauss.dms.data.model.LoginResponse
import com.bgauss.dms.data.model.MenuItemDto
import com.bgauss.dms.data.model.ModelPivotResponse
import com.bgauss.dms.data.model.ResetPasswordRequest
import com.bgauss.dms.data.model.RoleWiseMenuRightDto
import com.bgauss.dms.data.model.TotalSaleDealerWiseResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.HTTP
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/** AuthController – route `api/auth`. Paths are relative to BuildConfig.API_BASE_URL (…/api/). */
interface AuthApi {
    @POST("auth")
    suspend fun login(@Body body: LoginRequest): LoginResponse

    @POST("auth/location-login")
    suspend fun locationLogin(@Body body: LocationLoginRequest): LoginResponse

    /** Returns `{success,message}` or an empty 200 when the e-mail is unknown – hence raw body. */
    @POST("auth/forgot-password")
    suspend fun forgotPassword(@Body body: ForgotPasswordRequest): Response<ResponseBody>

    @POST("auth/reset-password")
    suspend fun resetPassword(@Body body: ResetPasswordRequest): Response<ResponseBody>
}

/** MenuController (`api/menu`) and RoleWiseMenuRightController (`api/role-wise-menu`). */
interface MenuApi {
    @GET("menu")
    suspend fun getMenu(): List<MenuItemDto>

    @GET("role-wise-menu/GetByRoleId")
    suspend fun getMyMenuRights(): List<RoleWiseMenuRightDto>
}

/** ReportController – route `api/Report` (endpoints used by the dashboard). */
interface ReportApi {
    @GET("Report/total-sale-dealer-wise")
    suspend fun totalSaleDealerWise(
        @Query("dealerCode") dealerCode: String? = null,
        @Query("fromDate") fromDate: String? = null,
        @Query("toDate") toDate: String? = null,
    ): TotalSaleDealerWiseResponse

    @GET("Report/model-wise-sale-count")
    suspend fun modelWiseSaleCount(
        @Query("dealerCode") dealerCode: String? = null,
        @Query("fromDate") fromDate: String? = null,
        @Query("toDate") toDate: String? = null,
    ): ModelPivotResponse

    @GET("Report/model-wise-stock-count")
    suspend fun modelWiseStockCount(
        @Query("dealerCode") dealerCode: String? = null,
        @Query("fromDate") fromDate: String? = null,
        @Query("toDate") toDate: String? = null,
    ): ModelPivotResponse

    @GET("Report/job-card/summary-stats")
    suspend fun jobCardSummaryStats(
        @Query("dealerCode") dealerCode: String,
        @Query("fromDate") fromDate: String? = null,
        @Query("toDate") toDate: String? = null,
    ): JobReportSummaryStats
}

/** CircularController, CircularDealerAssignmentController. */
interface CircularApi {
    /** `dealerCode` is the literal "null" for SuperAdmin, exactly as Angular sends it. */
    @GET("circular/GetByDealerCode/{dealerCode}")
    suspend fun getFolderTree(@Path("dealerCode") dealerCode: String): CircularFolderTree

    @GET("circular/GetCircularList")
    suspend fun getCircularList(): List<CircularDto>

    @GET("circular/{id}")
    suspend fun getById(@Path("id") id: Int): CircularDto

    @POST("circular")
    suspend fun create(@Body body: CircularDto): Response<ResponseBody>

    @PUT("circular")
    suspend fun update(@Body body: CircularDto): Response<ResponseBody>

    @GET("circular-dealer-assignment/{circularId}")
    suspend fun getDealerAssignments(@Path("circularId") circularId: Int): List<CircularDealerAssignmentDto>

    @POST("circular-dealer-assignment/{circularId}/dealer-permissions")
    suspend fun addDealerPermissions(
        @Path("circularId") circularId: Int,
        @Body body: List<CircularDealerAssignmentDto>,
    ): Response<ResponseBody>

    @HTTP(method = "DELETE", path = "circular-dealer-assignment/{circularId}/dealer-permissions", hasBody = true)
    suspend fun deleteDealerPermissions(
        @Path("circularId") circularId: Int,
        @Body body: List<CircularDealerAssignmentDto>,
    ): Response<ResponseBody>
}

package com.bgauss.dms.presentation.circular

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bgauss.dms.core.permission.AccessControl
import com.bgauss.dms.core.util.Formatters
import com.bgauss.dms.data.model.CircularItemDto
import com.bgauss.dms.presentation.components.EmptyState
import com.bgauss.dms.presentation.components.ErrorState
import com.bgauss.dms.presentation.components.LoadingState
import com.bgauss.dms.presentation.main.LocalSnackbar
import kotlinx.coroutines.flow.StateFlow

/** Menu id of the Circular page (app.routes.ts data: [53], circular.ts SUBMENU_ID). */
const val CIRCULAR_SUBMENU_ID = 53

/**
 * Circulars = the document library of the DMS: PDFs filed by Category → Year → Month → Date.
 * Buttons follow circular.html: Add needs SuperAdmin + Create; Edit/Configure need SuperAdmin + Edit.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CircularScreen(
    access: AccessControl,
    onAdd: () -> Unit,
    onEdit: (Int) -> Unit,
    onConfigure: (Int, String) -> Unit,
    onOpenPdf: (String, String) -> Unit,
    resultFlow: StateFlow<String>?,
    onResultConsumed: () -> Unit,
    viewModel: CircularViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    val canCreate = access.isSuperAdmin && access.canCreate(CIRCULAR_SUBMENU_ID)
    val canEdit = access.isSuperAdmin && access.canEdit(CIRCULAR_SUBMENU_ID)

    LaunchedEffect(Unit) {
        viewModel.events.collect { e ->
            when (e) {
                is CircularEvent.OpenPdf -> onOpenPdf(e.path, e.title)
                is CircularEvent.Message -> snackbar.showSnackbar(e.text)
            }
        }
    }
    // Result from the editor / permission screen: show the toast and reload, as uploadFiles() does.
    val result = resultFlow?.collectAsStateWithLifecycle()?.value
    LaunchedEffect(result) {
        if (!result.isNullOrBlank()) {
            onResultConsumed()
            viewModel.load()
            snackbar.showSnackbar(result)
        }
    }

    Box(Modifier.fillMaxSize()) {
        when {
            state.loading && state.tree.isEmpty() -> LoadingState()
            state.error != null && state.tree.isEmpty() -> ErrorState(state.error!!, onRetry = viewModel::load)
            else -> PullToRefreshBox(isRefreshing = state.loading, onRefresh = viewModel::load) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                    if (state.openingFile) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                    if (state.tree.isEmpty()) {
                        item { EmptyState(title = "No circulars", message = "No circulars have been published for you yet.") }
                    }
                    state.tree.forEach { (category, years) ->
                        item(key = "c_$category") {
                            FolderRow(category, depth = 0, open = state.openedCategory == category) { viewModel.toggleCategory(category) }
                        }
                        if (state.openedCategory == category) {
                            years.forEach { (year, months) ->
                                item(key = "y_${category}_$year") {
                                    FolderRow(year, depth = 1, open = state.openedYear == year) { viewModel.toggleYear(year) }
                                }
                                if (state.openedYear == year) {
                                    months.forEach { (month, dates) ->
                                        item(key = "m_${category}_${year}_$month") {
                                            FolderRow(month, depth = 2, open = state.openedMonth == month) { viewModel.toggleMonth(month) }
                                        }
                                        if (state.openedMonth == month) {
                                            dates.keys.forEach { date ->
                                                item(key = "d_${category}_${year}_${month}_$date") {
                                                    val sel = state.selection
                                                    val selected = sel != null && sel.category == category && sel.year == year && sel.month == month && sel.date == date
                                                    ListItem(
                                                        headlineContent = { Text(date.replace('-', '.'), fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) },
                                                        leadingContent = { Icon(Icons.Outlined.Event, null) },
                                                        colors = if (selected) ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.primaryContainer) else ListItemDefaults.colors(),
                                                        modifier = Modifier
                                                            .padding(start = 72.dp)
                                                            .clickable { viewModel.selectDate(category, year, month, date) },
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item(key = "div_$category") { HorizontalDivider() }
                    }

                    if (state.selection != null) {
                        item(key = "sel_header") {
                            Row(Modifier.fillMaxWidth().padding(16.dp, 16.dp, 16.dp, 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "${state.selection!!.category} · ${state.selection!!.date.replace('-', '.')}",
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(onClick = viewModel::clearSelection) { Text("Close") }
                            }
                        }
                        items(state.selectedCirculars, key = { "circ_${it.id}" }) { circular ->
                            CircularCard(
                                circular = circular,
                                canEdit = canEdit,
                                onEdit = { onEdit(circular.id) },
                                onConfigure = { onConfigure(circular.id, circular.title.orEmpty()) },
                                onOpen = viewModel::openFile,
                            )
                        }
                    }
                }
            }
        }
        if (canCreate) {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Outlined.Add, null) },
                text = { Text("Add") },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            )
        }
    }
}

@Composable
private fun FolderRow(label: String, depth: Int, open: Boolean, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(label, fontWeight = if (depth == 0) FontWeight.SemiBold else FontWeight.Normal) },
        leadingContent = { Icon(if (open) Icons.Outlined.FolderOpen else Icons.Outlined.Folder, null, tint = MaterialTheme.colorScheme.primary) },
        trailingContent = { Icon(if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null) },
        modifier = Modifier.padding(start = (depth * 24).dp).clickable(onClick = onClick),
    )
}

@Composable
private fun CircularCard(
    circular: CircularItemDto,
    canEdit: Boolean,
    onEdit: () -> Unit,
    onConfigure: () -> Unit,
    onOpen: (com.bgauss.dms.data.model.CircularFileDto) -> Unit,
) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(circular.title.orEmpty(), style = MaterialTheme.typography.titleSmall)
            Text(
                "${circular.category.orEmpty()} · Published ${Formatters.apiDate(circular.publishDate)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (!circular.description.isNullOrBlank()) Text(circular.description, style = MaterialTheme.typography.bodyMedium)
            val files = circular.files.orEmpty()
            if (files.isEmpty()) {
                Text("No attachments.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            files.forEach { f ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(f) }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.PictureAsPdf, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(f.fileName ?: "Attachment", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Text("View", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (canEdit) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onConfigure) {
                        Icon(Icons.Outlined.Settings, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Configure")
                    }
                    OutlinedButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Edit")
                    }
                }
            }
        }
    }
}

package com.bgauss.dms.presentation.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.CurrencyRupee
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TwoWheeler
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bgauss.dms.core.util.FinancialYear
import com.bgauss.dms.core.util.Formatters
import com.bgauss.dms.presentation.components.DateField
import com.bgauss.dms.presentation.components.DropdownField
import com.bgauss.dms.presentation.theme.BrandColors
import java.time.format.DateTimeFormatter

/** Report pages the dashboard drills into (dashboard.ts DASHBOARD_LINKS). */
private object Links {
    const val TOTAL_SALE = "/total-sale-dealer-wise"
    const val MODEL_SALE = "/model-wise-sale-report"
    const val MODEL_STOCK = "/model-wise-current-stock"
    const val JOB_CARDS = "/job-card-report"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onOpenLink: (link: String, title: String) -> Unit,
    viewModel: DashboardViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()

    PullToRefreshBox(isRefreshing = s.loading, onRefresh = viewModel::load, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RangeFilter(s, viewModel)

            s.firstError?.let {
                Text(
                    "Some figures could not be loaded: ${it.message}",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            // KPI cards
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Kpi(
                    "Units Sold", Formatters.number(s.unitsSold),
                    "${Formatters.number(s.cashCount)} cash · ${Formatters.number(s.creditCount)} credit",
                    Icons.Outlined.TwoWheeler, BrandColors.Blue, Modifier.weight(1f),
                ) { onOpenLink(Links.TOTAL_SALE, "Total Sale Dealer Wise") }
                Kpi(
                    "Sales Value", Formatters.inrCompact(s.salesValue),
                    "Avg. ${Formatters.inrCompact(s.avgTicket)} / unit",
                    Icons.Outlined.CurrencyRupee, BrandColors.Green, Modifier.weight(1f),
                ) { onOpenLink(Links.TOTAL_SALE, "Total Sale Dealer Wise") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Kpi(
                    "Vehicles in Stock", Formatters.number(s.stockUnits),
                    "Across ${Formatters.number(s.modelCount)} models",
                    Icons.Outlined.Storefront, BrandColors.Amber, Modifier.weight(1f),
                ) { onOpenLink(Links.MODEL_STOCK, "Model Wise Current Stock") }
                Kpi(
                    "Job Cards", Formatters.number(s.jobs?.totalJobs),
                    "${s.jobCompletionPct}% completed",
                    Icons.Outlined.Build, BrandColors.Purple, Modifier.weight(1f),
                ) { onOpenLink(Links.JOB_CARDS, "Job Card Report") }
            }

            SectionCard("Sales vs Stock by Model", onMore = { onOpenLink(Links.MODEL_SALE, "Model Wise Sale Report") }) {
                if (s.salesModels.isEmpty()) {
                    EmptyLine(s.loading, if (s.failedModelSale && s.failedStock) "Model data unavailable." else "No sales or stock to show.")
                } else {
                    Legend(listOf("Sold" to BrandColors.Blue, "In stock" to BrandColors.Amber))
                    val max = s.salesModels.maxOf { maxOf(it.sold, it.stock) }.coerceAtLeast(1.0)
                    s.salesModels.forEach { bar ->
                        Text(bar.model, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        HBar(bar.sold, max, BrandColors.Blue)
                        HBar(bar.stock, max, BrandColors.Amber)
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }

            SectionCard("Stock by Model", onMore = { onOpenLink(Links.MODEL_STOCK, "Model Wise Current Stock") }) {
                if (s.stockRows.isEmpty()) {
                    EmptyLine(s.loading, if (s.failedStock) "Stock data unavailable." else "No vehicles in stock.")
                } else {
                    val max = s.stockRows.maxOf { it.units }.coerceAtLeast(1.0)
                    s.stockRows.forEachIndexed { i, row ->
                        Text(row.model, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        HBar(row.units, max, BrandColors.Chart[i % BrandColors.Chart.size])
                    }
                }
            }

            SectionCard("Top Dealers by Units", onMore = { onOpenLink(Links.TOTAL_SALE, "Total Sale Dealer Wise") }) {
                if (s.topDealers.isEmpty()) {
                    EmptyLine(s.loading, if (s.failedSale) "Sales data unavailable." else "No sales in this period.")
                } else {
                    s.topDealers.forEachIndexed { i, d ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) { Text("${i + 1}", style = MaterialTheme.typography.labelSmall) }
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.dealerName.orEmpty(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    listOfNotNull(d.dealerCode, d.dealerCity?.takeIf { it.isNotBlank() }).joinToString(" · "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Formatters.number(d.totalUnitsSold), fontWeight = FontWeight.SemiBold)
                                Text(Formatters.inrCompact(d.totalFinalAmount), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (i < s.topDealers.lastIndex) HorizontalDivider()
                    }
                }
            }

            SectionCard("Payment Mix", onMore = { onOpenLink(Links.TOTAL_SALE, "Total Sale Dealer Wise") }) {
                val total = s.cashCount + s.creditCount
                if (total == 0.0) {
                    EmptyLine(s.loading, "No sales in this period.")
                } else {
                    SplitBar(listOf(s.cashCount to BrandColors.Green, s.creditCount to BrandColors.Blue))
                    Legend(
                        listOf(
                            "Cash ${Formatters.number(s.cashCount)} (${pct(s.cashCount, total)}%)" to BrandColors.Green,
                            "Credit ${Formatters.number(s.creditCount)} (${pct(s.creditCount, total)}%)" to BrandColors.Blue,
                        ),
                    )
                }
            }

            SectionCard("Job Card Status", onMore = { onOpenLink(Links.JOB_CARDS, "Job Card Report") }) {
                val j = s.jobs
                if (j == null || j.totalJobs == 0.0) {
                    EmptyLine(s.loading, if (s.failedJobs) "Job card data unavailable." else "No job cards in this period.")
                } else {
                    Text("${s.jobCompletionPct}% completed", style = MaterialTheme.typography.titleMedium)
                    LinearProgressIndicator(
                        progress = { (j.completedJobs / j.totalJobs).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = BrandColors.Purple,
                    )
                    Legend(
                        listOf(
                            "Completed ${Formatters.number(j.completedJobs)}" to BrandColors.Purple,
                            "Pending ${Formatters.number(j.pendingJobs)}" to MaterialTheme.colorScheme.outline,
                        ),
                    )
                    Text(
                        "Revenue ${Formatters.inrCompact(j.totalRevenue)} · Avg ${Formatters.inrCompact(j.averageJobValue)} / job",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            s.lastUpdated?.let {
                Text(
                    "Updated ${it.format(DateTimeFormatter.ofPattern("dd.MM.yyyy hh:mm a"))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun pct(part: Double, total: Double): Int = if (total > 0) Math.round(part / total * 100).toInt() else 0

@Composable
private fun RangeFilter(s: DashboardUiState, vm: DashboardViewModel) {
    val fys = FinancialYear.options()
    val selectedFy = fys.firstOrNull { it.from == s.from && it.to == s.to }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Formatters.range(s.from, s.to), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                IconButton(onClick = vm::load, enabled = !s.loading) { Icon(Icons.Outlined.Refresh, contentDescription = "Refresh") }
            }
            DropdownField(
                label = "Financial Year",
                options = listOf<FinancialYear.Option?>(null) + fys,
                selected = selectedFy,
                optionLabel = { it?.label ?: "All (since 01.01.2020)" },
                onSelected = { opt ->
                    if (opt == null) {
                        val (f, t) = FinancialYear.defaultRange()
                        vm.setRange(f, t)
                    } else {
                        vm.setRange(opt.from, opt.to)
                    }
                },
                enabled = !s.loading,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("From", s.from, { vm.setRange(it, s.to) }, Modifier.weight(1f), enabled = !s.loading, maxDate = s.to)
                DateField("To", s.to, { vm.setRange(s.from, it) }, Modifier.weight(1f), enabled = !s.loading, minDate = s.from)
            }
        }
    }
}

@Composable
private fun Kpi(
    label: String,
    value: String,
    sub: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Card(modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            }
            Text(value, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

@Composable
private fun SectionCard(title: String, onMore: () -> Unit, content: @Composable () -> Unit) {
    Card {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onMore), verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text("View report ›", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}

@Composable
private fun EmptyLine(loading: Boolean, text: String) {
    Text(
        if (loading) "Loading…" else text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 16.dp),
    )
}

@Composable
private fun HBar(value: Double, max: Double, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth((value / max).toFloat().coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(5.dp))
                    .background(color),
            )
        }
        Text(
            Formatters.number(value),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.width(56.dp).padding(start = 8.dp),
        )
    }
}

@Composable
private fun SplitBar(parts: List<Pair<Double, Color>>) {
    val total = parts.sumOf { it.first }.coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp))) {
        parts.filter { it.first > 0 }.forEach { (v, c) ->
            Box(Modifier.weight((v / total).toFloat()).fillMaxHeight().background(c))
        }
    }
}

@Composable
private fun Legend(items: List<Pair<String, Color>>) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 4.dp)) {
        items.forEach { (label, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                Spacer(Modifier.width(4.dp))
                Text(label, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

package com.bgauss.dms.presentation.navigation

import android.net.Uri

/** Top-level graph (no session → auth screens; session → Home shell). */
object RootRoutes {
    const val LOGIN = "login"
    const val FORGOT = "forgot-password"
    const val RESET = "reset-password?email={email}&token={token}"
    const val HOME = "home"

    fun reset(email: String?, token: String?): String =
        "reset-password?email=${Uri.encode(email.orEmpty())}&token=${Uri.encode(token.orEmpty())}"
}

/** Destinations inside the Home shell (drawer + top bar). */
object HomeRoutes {
    const val DASHBOARD = "dashboard"
    const val CIRCULAR = "circular"
    const val CIRCULAR_EDITOR = "circular/editor?id={id}"
    const val CIRCULAR_PERMISSION = "circular/permission/{id}?title={title}"
    const val PDF_VIEWER = "document/pdf?path={path}&title={title}"
    const val NOT_CONVERTED = "not-converted?link={link}&title={title}"

    fun circularEditor(id: Int?) = "circular/editor?id=${id ?: 0}"
    fun circularPermission(id: Int, title: String) = "circular/permission/$id?title=${Uri.encode(title)}"
    fun pdfViewer(path: String, title: String) = "document/pdf?path=${Uri.encode(path)}&title=${Uri.encode(title)}"
    fun notConverted(link: String, title: String) = "not-converted?link=${Uri.encode(link)}&title=${Uri.encode(title)}"
}

/**
 * Maps a web menu link to the Android screen that implements it. Links without an Android
 * screen yet open [HomeRoutes.NOT_CONVERTED] (the web app's WorkInProgress equivalent) so the
 * drawer still mirrors the user's full web menu.
 */
object RouteRegistry {
    private val implemented: Map<String, String> = mapOf(
        "/" to HomeRoutes.DASHBOARD,
        "/circular" to HomeRoutes.CIRCULAR,
    )

    fun isImplemented(link: String): Boolean = implemented.containsKey(normalize(link))

    fun destinationFor(link: String, title: String): String =
        implemented[normalize(link)] ?: HomeRoutes.notConverted(link, title)

    /** Route `data` subMenuId for the guard; null if the link is not a known web route. */
    fun subMenuIdFor(link: String): Int? = AngularRoutes.find(link)?.subMenuId

    private fun normalize(link: String): String = link.substringBefore('?').trimEnd('/').ifEmpty { "/" }.lowercase()
}

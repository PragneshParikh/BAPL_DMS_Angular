package com.bgauss.dms.data.repository

import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.network.bodyTextOrThrow
import com.bgauss.dms.core.network.safeApiCall
import com.bgauss.dms.core.session.AppModule
import com.bgauss.dms.core.session.SessionManager
import com.bgauss.dms.core.session.StoredMenuRight
import com.bgauss.dms.core.session.UserSession
import com.bgauss.dms.data.api.AuthApi
import com.bgauss.dms.data.api.MenuApi
import com.bgauss.dms.data.model.ForgotPasswordRequest
import com.bgauss.dms.data.model.LocationLoginRequest
import com.bgauss.dms.data.model.LocationOption
import com.bgauss.dms.data.model.LoginRequest
import com.bgauss.dms.data.model.LoginResponse
import com.bgauss.dms.data.model.ResetPasswordRequest
import com.bgauss.dms.data.model.SimpleResult
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

sealed interface LoginOutcome {
    data class LoggedIn(val message: String) : LoginOutcome

    /** Location Login linked to several locations: user must pick one (step 2 = location-login). */
    data class ChooseLocation(
        val locationLoginId: String,
        val locations: List<LocationOption>,
        val message: String,
    ) : LoginOutcome

    data class Rejected(val message: String) : LoginOutcome
}

@Singleton
class AuthRepository @Inject constructor(
    private val authApi: AuthApi,
    private val menuApi: MenuApi,
    private val sessionManager: SessionManager,
    private val json: Json,
) {
    /**
     * POST api/auth. The backend resolves AspNetUsers login, Location Login ID, or dealer
     * auto-provisioning from the same username field (AuthController.Login).
     */
    suspend fun login(username: String, password: String): ApiResult<LoginOutcome> {
        val result = safeApiCall { authApi.login(LoginRequest(username.trim(), password)) }
        return handleLoginResult(result)
    }

    /** Step 2 of multi-location Location Login: POST api/auth/location-login with the chosen code. */
    suspend fun completeLocationLogin(
        locationLoginId: String,
        password: String,
        locationCode: String,
    ): ApiResult<LoginOutcome> {
        val result = safeApiCall {
            authApi.locationLogin(LocationLoginRequest(locationLoginId.trim(), password, locationCode))
        }
        return handleLoginResult(result)
    }

    private suspend fun handleLoginResult(result: ApiResult<LoginResponse>): ApiResult<LoginOutcome> =
        when (result) {
            is ApiResult.Failure -> result
            is ApiResult.Success -> {
                val r = result.data
                when {
                    r.requiresLocationSelection -> ApiResult.Success(
                        LoginOutcome.ChooseLocation(
                            locationLoginId = r.locationLoginId.orEmpty(),
                            locations = r.locations.orEmpty(),
                            message = r.message ?: "This login is linked to multiple locations. Please select one.",
                        ),
                    )
                    r.isSuccess -> {
                        startSession(r)
                        val msg = r.message ?: "Login successful"
                        ApiResult.Success(
                            LoginOutcome.LoggedIn(if (r.locationCode != null) "$msg — Location: ${r.locationCode}" else msg),
                        )
                    }
                    else -> ApiResult.Success(LoginOutcome.Rejected(r.message ?: "Login failed"))
                }
            }
        }

    /**
     * Saves the session, then loads the caller's role rights (Angular sidebar
     * loadRoleWiseMenuRights → GET api/role-wise-menu/GetByRoleId) so page guards work offline of the menu call.
     */
    private suspend fun startSession(r: LoginResponse) {
        val session = UserSession(
            token = r.token!!,
            userId = r.userId,
            email = r.email,
            userName = r.userName,
            firstName = r.firstName,
            lastName = r.lastName,
            role = r.role.orEmpty(),
            roles = r.roles.orEmpty(),
            dealerCode = r.dealerCode?.takeIf { it.isNotBlank() },
            employeeCode = r.employeeCode,
            mappedZones = r.mappedZones,
            locationCode = r.locationCode?.takeIf { it.isNotBlank() },
            locationRoleId = r.locationRoleId?.takeIf { it.isNotBlank() },
            compName = r.compName,
            lastLoginDate = r.lastLoginDate,
            selectedModule = AppModule.ShowRoom.key,
        )
        sessionManager.start(session)
        refreshMenuRights()
    }

    suspend fun refreshMenuRights(): ApiResult<Unit> {
        val rights = safeApiCall { menuApi.getMyMenuRights() }
        if (rights is ApiResult.Success) {
            sessionManager.update { s ->
                s.copy(menuRights = rights.data.map { StoredMenuRight(it.subMenuId, it.permission) })
            }
            return ApiResult.Success(Unit)
        }
        return rights as ApiResult.Failure
    }

    suspend fun forgotPassword(email: String): ApiResult<SimpleResult> = safeApiCall {
        val text = authApi.forgotPassword(ForgotPasswordRequest(email.trim())).bodyTextOrThrow()
        parseSimpleResult(text)
            // Backend returns an empty 200 when the e-mail is not registered. Keep the reply neutral
            // so the screen does not reveal which e-mails have accounts.
            ?: SimpleResult(success = true, message = "If this e-mail is registered, a reset link has been sent.")
    }

    suspend fun resetPassword(email: String, token: String, password: String, confirm: String): ApiResult<SimpleResult> =
        safeApiCall {
            val text = authApi.resetPassword(ResetPasswordRequest(email.trim(), token, password, confirm)).bodyTextOrThrow()
            parseSimpleResult(text) ?: SimpleResult(success = true, message = "Password reset successful")
        }

    private fun parseSimpleResult(text: String): SimpleResult? =
        if (text.isBlank()) null else runCatching { json.decodeFromString(SimpleResult.serializer(), text) }.getOrNull()

    fun logout() = sessionManager.logout()
}

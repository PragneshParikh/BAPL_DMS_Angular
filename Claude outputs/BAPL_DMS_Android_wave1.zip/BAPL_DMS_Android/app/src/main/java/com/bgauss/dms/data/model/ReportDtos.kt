package com.bgauss.dms.data.model

import kotlinx.serialization.Serializable

/** GET api/Report/total-sale-dealer-wise (ViewModels/models/total-sale-reportModel.ts). */
@Serializable
data class TotalSaleDealerWiseResponse(
    val rows: List<TotalSaleDealerWiseRow> = emptyList(),
    val grandTotal: TotalSaleDealerWiseRow? = null,
)

@Serializable
data class TotalSaleDealerWiseRow(
    val dealerCode: String? = null,
    val dealerName: String? = null,
    val dealerCity: String? = null,
    val dealerState: String? = null,
    val totalUnitsSold: Double = 0.0,
    val cashCount: Double = 0.0,
    val creditCount: Double = 0.0,
    val totalItemRate: Double = 0.0,
    val totalPreGstDiscount: Double = 0.0,
    val totalTaxableAmount: Double = 0.0,
    val totalSgstAmount: Double = 0.0,
    val totalCgstAmount: Double = 0.0,
    val totalIgstAmount: Double = 0.0,
    val totalFameIIDiscount: Double = 0.0,
    val totalRegAmount: Double = 0.0,
    val totalInsuranceAmount: Double = 0.0,
    val totalPostGstDiscount: Double = 0.0,
    val totalFinalAmount: Double = 0.0,
    val totalAmount: Double = 0.0,
)

/**
 * GET api/Report/model-wise-sale-count and api/Report/model-wise-stock-count
 * (pivot Dealer x Model, same shape for both).
 */
@Serializable
data class ModelPivotResponse(
    val modelNames: List<String> = emptyList(),
    val rows: List<ModelPivotRow> = emptyList(),
    val columnTotals: Map<String, Double> = emptyMap(),
    val grandTotal: Double = 0.0,
)

@Serializable
data class ModelPivotRow(
    val dealerCode: String? = null,
    val dealerName: String? = null,
    val modelCounts: Map<String, Double> = emptyMap(),
    val total: Double = 0.0,
)

/** GET api/Report/job-card/summary-stats (JobReportSummaryStats). */
@Serializable
data class JobReportSummaryStats(
    val totalJobs: Double = 0.0,
    val totalRevenue: Double = 0.0,
    val totalTaxes: Double = 0.0,
    val completedJobs: Double = 0.0,
    val pendingJobs: Double = 0.0,
    val averageJobValue: Double = 0.0,
)

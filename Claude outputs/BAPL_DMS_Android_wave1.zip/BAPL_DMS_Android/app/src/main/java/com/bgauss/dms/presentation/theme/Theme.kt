package com.bgauss.dms.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Brand colours taken from the Angular login.scss and dashboard palette. */
object BrandColors {
    val Navy = Color(0xFF0A2540)
    val Primary = Color(0xFF1E3A5F)
    val PrimaryLight = Color(0xFF2D5580)
    val Volt = Color(0xFF00E676)
    val Slate = Color(0xFF7C8798)
    val CardBg = Color(0xFFF5F7FA)
    val Danger = Color(0xFFDC3545)

    // Dashboard chart palette (dashboard.ts C / PALETTE)
    val Blue = Color(0xFF5B8DEF)
    val Green = Color(0xFF34D399)
    val Amber = Color(0xFFFBBF24)
    val Purple = Color(0xFFA78BFA)
    val Pink = Color(0xFFF472B6)
    val Teal = Color(0xFF2DD4BF)
    val Orange = Color(0xFFFB923C)
    val Sky = Color(0xFF60A5FA)
    val Chart = listOf(Blue, Green, Amber, Purple, Pink, Teal, Orange, Sky)
}

private val LightColors = lightColorScheme(
    primary = BrandColors.Primary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E3F4),
    onPrimaryContainer = BrandColors.Navy,
    secondary = BrandColors.PrimaryLight,
    onSecondary = Color.White,
    tertiary = Color(0xFF00A85A),
    background = Color.White,
    surface = Color.White,
    surfaceVariant = BrandColors.CardBg,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = BrandColors.Danger,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9DC1EA),
    onPrimary = BrandColors.Navy,
    primaryContainer = BrandColors.Primary,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFB5CBE6),
    tertiary = BrandColors.Volt,
    background = Color(0xFF0B0F14),
    surface = Color(0xFF111821),
    surfaceVariant = Color(0xFF1B2533),
    error = Color(0xFFFF6B7A),
)

private val AppTypography = Typography().let { base ->
    base.copy(
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp),
    )
}

@Composable
fun BaplDmsTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}

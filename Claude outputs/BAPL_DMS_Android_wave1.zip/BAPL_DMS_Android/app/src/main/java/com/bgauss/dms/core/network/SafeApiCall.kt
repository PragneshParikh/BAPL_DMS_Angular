package com.bgauss.dms.core.network

import kotlinx.coroutines.CancellationException
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import retrofit2.HttpException
import java.io.IOException

/**
 * Wraps a Retrofit suspend call and converts every failure into [ApiResult.Failure]
 * with a user-facing message, the way the Angular toasts did.
 */
suspend fun <T> safeApiCall(block: suspend () -> T): ApiResult<T> = try {
    ApiResult.Success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: HttpException) {
    val body = runCatching { e.response()?.errorBody()?.string() }.getOrNull()
    val serverMessage = extractServerMessage(body)
    val code = e.code()
    val kind = when (code) {
        401 -> ApiResult.Kind.Unauthorized
        403 -> ApiResult.Kind.Forbidden
        in 400..499 -> ApiResult.Kind.Client
        else -> ApiResult.Kind.Server
    }
    val fallback = when (kind) {
        ApiResult.Kind.Unauthorized -> "Session expired or invalid. Please log in again."
        ApiResult.Kind.Forbidden -> "You do not have access to this function."
        ApiResult.Kind.Server -> "Server error ($code). Please try again later."
        else -> "Request failed ($code)."
    }
    ApiResult.Failure(kind, serverMessage ?: fallback, code)
} catch (e: SerializationException) {
    ApiResult.Failure(ApiResult.Kind.Parse, "Unexpected response from server.")
} catch (e: IllegalArgumentException) {
    // kotlinx.serialization throws IllegalArgumentException subclasses for missing fields.
    ApiResult.Failure(ApiResult.Kind.Parse, "Unexpected response from server.")
} catch (e: IOException) {
    ApiResult.Failure(ApiResult.Kind.Network, "Unable to reach the server. Check your internet connection.")
}

private val lenientJson = Json { ignoreUnknownKeys = true; isLenient = true }

/**
 * The API returns errors in several shapes: `{ message }`, `{ Message }`, `{ success:false, message }`,
 * `{ title, errors }` (ASP.NET validation) or a bare string. Pick the first readable one.
 */
internal fun extractServerMessage(body: String?): String? {
    if (body.isNullOrBlank()) return null
    val trimmed = body.trim()
    if (!trimmed.startsWith("{")) {
        return trimmed.removeSurrounding("\"").takeIf { it.isNotBlank() && it.length < 300 }
    }
    val obj = runCatching { lenientJson.parseToJsonElement(trimmed) as? JsonObject }.getOrNull() ?: return null
    val details = (obj["errors"] as? JsonPrimitive)?.takeIf { it.isString }?.content
    for (key in listOf("message", "Message", "error", "title", "Description", "description")) {
        val value = obj[key]
        if (value is JsonPrimitive && value.isString) {
            val text = value.content
            if (text.isNotBlank()) return if (details.isNullOrBlank()) text else "$text: $details"
        }
    }
    return details
}

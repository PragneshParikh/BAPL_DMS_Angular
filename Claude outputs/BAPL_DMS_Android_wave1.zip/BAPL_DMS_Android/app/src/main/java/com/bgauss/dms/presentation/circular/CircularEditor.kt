package com.bgauss.dms.presentation.circular

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.util.DocumentFiles
import com.bgauss.dms.core.util.Formatters
import com.bgauss.dms.data.model.CircularDto
import com.bgauss.dms.data.repository.CircularForm
import com.bgauss.dms.data.repository.CircularRepository
import com.bgauss.dms.data.repository.NewAttachment
import com.bgauss.dms.presentation.components.DateField
import com.bgauss.dms.presentation.components.DropdownField
import com.bgauss.dms.presentation.components.ErrorState
import com.bgauss.dms.presentation.components.LoadingState
import com.bgauss.dms.presentation.main.LocalSnackbar
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import javax.inject.Inject

/** Category options in dialogs/add-circular/add-circular.html. */
val CIRCULAR_CATEGORIES = listOf("Sales", "Service")

data class CircularEditorState(
    val loading: Boolean = true,
    val loadError: ApiResult.Failure? = null,
    val form: CircularForm = CircularForm(),
    val submitted: Boolean = false,
    val saving: Boolean = false,
    val message: String? = null,
    val savedMessage: String? = null,
) {
    val isEdit get() = form.id > 0
    val categoryError get() = if (submitted && form.category.isBlank()) "Category is required" else null
    val dateError get() = if (submitted && form.publishDate == null) "Date is required" else null
    val titleError get() = if (submitted && form.title.isBlank()) "Title is required" else null
    val isValid get() = form.category.isNotBlank() && form.publishDate != null && form.title.isNotBlank()
}

@HiltViewModel
class CircularEditorViewModel @Inject constructor(
    private val repository: CircularRepository,
    @ApplicationContext private val context: Context,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val id: Int = savedStateHandle.get<Int>("id") ?: 0
    private var existing: List<CircularDto> = emptyList()

    private val _state = MutableStateFlow(CircularEditorState())
    val state = _state.asStateFlow()

    init {
        load()
    }

    /** ngOnInit(): circular list (for the duplicate check) and, in edit mode, the record by id. */
    fun load() {
        _state.update { it.copy(loading = true, loadError = null) }
        viewModelScope.launch {
            when (val all = repository.loadAll()) {
                is ApiResult.Success -> existing = all.data
                is ApiResult.Failure -> {
                    _state.update { it.copy(loading = false, loadError = all) }
                    return@launch
                }
            }
            if (id > 0) {
                when (val r = repository.getById(id)) {
                    is ApiResult.Success -> {
                        val c = r.data
                        _state.update {
                            it.copy(
                                loading = false,
                                form = CircularForm(
                                    id = c.id,
                                    category = c.category ?: "Sales",
                                    title = c.title,
                                    description = c.description.orEmpty(),
                                    publishDate = c.publishDate?.let { d -> Formatters.parseApiDate(d) },
                                    expiryDate = c.expiryDate,
                                    isActive = c.isActive,
                                    existingFiles = c.files.orEmpty(),
                                    createdBy = c.createdBy,
                                    createdDate = c.createdDate,
                                ),
                            )
                        }
                    }
                    is ApiResult.Failure -> _state.update { it.copy(loading = false, loadError = r) }
                }
            } else {
                _state.update { it.copy(loading = false) }
            }
        }
    }

    private fun edit(block: (CircularForm) -> CircularForm) = _state.update { it.copy(form = block(it.form)) }

    fun onTitle(v: String) = edit { it.copy(title = v) }
    fun onDescription(v: String) = edit { it.copy(description = v) }
    fun onActive(v: Boolean) = edit { it.copy(isActive = v) }

    /** checkDuplicate(): same category on the same date is not allowed → date cleared. */
    fun onCategory(v: String) {
        edit { it.copy(category = v) }
        val date = _state.value.form.publishDate ?: return
        if (isDuplicate(v, date)) {
            edit { it.copy(publishDate = null) }
            _state.update { it.copy(message = "$v circular already exists for this date.") }
        }
    }

    /** checkDuplicateDate(). */
    fun onDate(date: LocalDate) {
        val category = _state.value.form.category
        if (isDuplicate(category, date)) {
            edit { it.copy(publishDate = null) }
            _state.update { it.copy(message = "$category circular already exists for this date.") }
        } else {
            edit { it.copy(publishDate = date) }
        }
    }

    private fun isDuplicate(category: String, date: LocalDate): Boolean = existing.any { c ->
        c.publishDate?.take(10) == date.toString() && c.category == category && c.id != id
    }

    /** onFileSelected(): PDFs only; others rejected with a message. */
    fun onFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val picked = withContext(Dispatchers.IO) {
                uris.map { uri -> runCatching { DocumentFiles.read(context, uri) }.getOrNull() }
            }
            var rejected = 0
            val added = picked.mapNotNull { f ->
                if (f == null || !(f.mimeType == "application/pdf" || f.name.endsWith(".pdf", ignoreCase = true))) {
                    rejected++
                    null
                } else {
                    NewAttachment(f.name, "application/pdf", Base64.encodeToString(f.bytes, Base64.NO_WRAP))
                }
            }
            edit { it.copy(newFiles = it.newFiles + added) }
            if (rejected > 0) _state.update { it.copy(message = "Only PDF files are allowed.") }
        }
    }

    fun removeNewFile(index: Int) = edit { it.copy(newFiles = it.newFiles.filterIndexed { i, _ -> i != index }) }

    /** removeFile(): existing attachment is marked Deleted and sent to the API on save. */
    fun removeExistingFile(attachmentId: Int) = edit { it.copy(removedAttachmentIds = it.removedAttachmentIds + attachmentId) }

    fun messageShown() = _state.update { it.copy(message = null) }

    fun save(userId: String) {
        _state.update { it.copy(submitted = true) }
        val s = _state.value
        if (!s.isValid || s.saving) return
        _state.update { it.copy(saving = true) }
        viewModelScope.launch {
            when (val r = repository.save(s.form, userId)) {
                is ApiResult.Success -> _state.update {
                    it.copy(saving = false, savedMessage = if (s.isEdit) "Records updated successfully." else "Files uploaded successfully.")
                }
                is ApiResult.Failure -> _state.update { it.copy(saving = false, message = r.message.ifBlank { "Something went wrong." }) }
            }
        }
    }
}

@Composable
fun CircularEditorScreen(
    userId: String,
    onDone: (String) -> Unit,
    onCancel: () -> Unit,
    viewModel: CircularEditorViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        viewModel.onFilesPicked(uris)
    }

    LaunchedEffect(s.message) { s.message?.let { snackbar.showSnackbar(it); viewModel.messageShown() } }
    LaunchedEffect(s.savedMessage) { s.savedMessage?.let(onDone) }

    when {
        s.loading -> LoadingState()
        s.loadError != null -> ErrorState(s.loadError!!, onRetry = viewModel::load)
        else -> Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(if (s.isEdit) "Edit Circular" else "Add Circular", style = MaterialTheme.typography.titleLarge)
            DropdownField(
                label = "Category",
                options = CIRCULAR_CATEGORIES,
                selected = s.form.category,
                optionLabel = { it },
                onSelected = viewModel::onCategory,
                required = true,
                error = s.categoryError,
            )
            DateField(
                label = "Select Date",
                value = s.form.publishDate,
                onValueChange = viewModel::onDate,
                required = true,
                error = s.dateError,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Active", modifier = Modifier.weight(1f))
                Text(if (s.form.isActive) "Y" else "N", modifier = Modifier.padding(end = 8.dp))
                Switch(checked = s.form.isActive, onCheckedChange = viewModel::onActive)
            }
            OutlinedTextField(
                value = s.form.title,
                onValueChange = viewModel::onTitle,
                label = { Text("Title *") },
                placeholder = { Text("Enter title") },
                isError = s.titleError != null,
                supportingText = s.titleError?.let { msg -> @Composable { Text(msg) } },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = s.form.description,
                onValueChange = viewModel::onDescription,
                label = { Text("Description") },
                placeholder = { Text("Enter description") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Attachments (PDF)", style = MaterialTheme.typography.titleSmall)
            s.form.existingFiles.filter { it.attachmentId !in s.form.removedAttachmentIds }.forEach { f ->
                FileRow(f.fileName ?: "Attachment", "Saved") { viewModel.removeExistingFile(f.attachmentId) }
            }
            s.form.newFiles.forEachIndexed { i, f ->
                FileRow(f.fileName, "New") { viewModel.removeNewFile(i) }
            }
            OutlinedButton(onClick = { picker.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Outlined.AttachFile, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Choose PDF files")
            }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { viewModel.save(userId) }, enabled = !s.saving, modifier = Modifier.weight(1f)) {
                    if (s.saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    else Text("Save")
                }
                OutlinedButton(onClick = onCancel, enabled = !s.saving, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun FileRow(name: String, tag: String, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.PictureAsPdf, null, tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.bodyMedium)
            Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, contentDescription = "Remove $name") }
    }
}

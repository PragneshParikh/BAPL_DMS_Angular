package com.bgauss.dms.core.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.File

/**
 * File plumbing for documents: decoding base64 attachments, caching them for preview,
 * reading files chosen with the system picker, saving to Downloads and opening/sharing.
 */
object DocumentFiles {

    private const val CACHE_DIR = "documents"

    fun authority(context: Context) = "${context.packageName}.fileprovider"

    /** Keeps letters, digits, dot, dash, underscore and space; never empty. */
    fun safeName(name: String?, fallback: String = "document.pdf"): String {
        val cleaned = name.orEmpty().replace(Regex("[^A-Za-z0-9._\\- ]"), "_").trim()
        return cleaned.ifBlank { fallback }.take(120)
    }

    /** Decodes a base64 attachment into the app cache (cleared by the OS when space is low). */
    fun cacheBase64(context: Context, base64: String, fileName: String): File {
        val dir = File(context.cacheDir, CACHE_DIR).apply { mkdirs() }
        val file = File(dir, safeName(fileName))
        file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
        return file
    }

    fun cacheBytes(context: Context, bytes: ByteArray, fileName: String): File {
        val dir = File(context.cacheDir, CACHE_DIR).apply { mkdirs() }
        return File(dir, safeName(fileName)).apply { writeBytes(bytes) }
    }

    data class PickedFile(val name: String, val mimeType: String, val size: Long, val bytes: ByteArray)

    /** Reads a document returned by ACTION_OPEN_DOCUMENT. */
    fun read(context: Context, uri: Uri): PickedFile {
        val resolver = context.contentResolver
        var name = "document"
        var size = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
        return PickedFile(name, mime, if (size >= 0) size else bytes.size.toLong(), bytes)
    }

    /**
     * Copies a cached file to the public Downloads folder (MediaStore on Android 10+,
     * app-specific Downloads on 8–9 so no storage permission is needed). Returns a viewable Uri.
     */
    fun saveToDownloads(context: Context, source: File, mimeType: String): Uri {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BGauss DMS")
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create the file in Downloads")
            resolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
            uri
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val target = File(dir, source.name)
            source.copyTo(target, overwrite = true)
            FileProvider.getUriForFile(context, authority(context), target)
        }
    }

    fun contentUri(context: Context, file: File): Uri = FileProvider.getUriForFile(context, authority(context), file)

    fun viewIntent(uri: Uri, mimeType: String): Intent =
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeType).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

    fun shareIntent(uri: Uri, mimeType: String, title: String): Intent = Intent.createChooser(
        Intent(Intent.ACTION_SEND).setType(mimeType).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
        title,
    )
}

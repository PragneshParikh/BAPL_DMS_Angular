package com.bgauss.dms.core.network

import okhttp3.ResponseBody
import retrofit2.HttpException
import retrofit2.Response

/**
 * For endpoints declared as `Response<ResponseBody>` (empty or untyped bodies):
 * throws [HttpException] on non-2xx so [safeApiCall] maps it like any other failure,
 * and returns the body text (possibly empty) on success.
 */
fun Response<ResponseBody>.bodyTextOrThrow(): String {
    if (!isSuccessful) throw HttpException(this)
    return body()?.use { it.string() }.orEmpty()
}

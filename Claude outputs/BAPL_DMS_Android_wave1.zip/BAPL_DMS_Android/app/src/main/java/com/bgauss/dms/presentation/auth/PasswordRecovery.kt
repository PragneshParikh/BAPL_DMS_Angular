package com.bgauss.dms.presentation.auth

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.data.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

// ---------------------------------------------------------------- Forgot password

data class ForgotUiState(
    val email: String = "",
    val submitted: Boolean = false,
    val isLoading: Boolean = false,
    val message: String? = null,
) {
    val emailError: String? get() = if (submitted && email.isBlank()) "Email is required" else null
}

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(
    private val authRepository: AuthRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(ForgotUiState())
    val state = _state.asStateFlow()

    fun onEmail(v: String) = _state.update { it.copy(email = v) }
    fun messageShown() = _state.update { it.copy(message = null) }

    /** forgot-password.ts onSubmit(): POST auth/forgot-password { email }. */
    fun submit() {
        _state.update { it.copy(submitted = true) }
        val s = _state.value
        if (s.email.isBlank() || s.isLoading) return
        _state.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            when (val r = authRepository.forgotPassword(s.email)) {
                is ApiResult.Success -> _state.update {
                    if (r.data.success) ForgotUiState(message = r.data.message ?: "Password reset link sent.")
                    else it.copy(isLoading = false, message = r.data.message ?: "Password reset failed. Please try again.")
                }
                is ApiResult.Failure -> _state.update {
                    it.copy(
                        isLoading = false,
                        message = if (r.kind == ApiResult.Kind.Network) r.message
                        else "An error occurred while sending the password reset email. Please try again.",
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForgotPasswordScreen(
    onBack: () -> Unit,
    onHaveResetLink: () -> Unit,
    viewModel: ForgotPasswordViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); viewModel.messageShown() }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Forgot Password") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(20.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Enter your registered e-mail. A password reset link will be sent to it.", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = state.email,
                onValueChange = viewModel::onEmail,
                label = { Text("Email *") },
                isError = state.emailError != null,
                supportingText = state.emailError?.let { msg -> @Composable { Text(msg) } },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = viewModel::submit, enabled = !state.isLoading, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                if (state.isLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                else Text("Send Reset Link")
            }
            Button(onClick = onHaveResetLink, modifier = Modifier.fillMaxWidth()) { Text("I already have a reset link") }
        }
    }
}

// ---------------------------------------------------------------- Reset password

data class ResetUiState(
    val email: String = "",
    val token: String = "",
    val resetLink: String = "",
    val password: String = "",
    val confirm: String = "",
    val submitted: Boolean = false,
    val isLoading: Boolean = false,
    val message: String? = null,
    val done: Boolean = false,
) {
    val passwordError: String? get() = if (submitted && password.isEmpty()) "Password is required" else null
    val confirmError: String?
        get() = when {
            submitted && confirm.isEmpty() -> "Confirm password is required"
            submitted && confirm != password -> "Passwords do not match"
            else -> null
        }
    val linkError: String?
        get() = if (submitted && (email.isBlank() || token.isBlank())) "Paste the full reset link from the e-mail" else null

    // Hints shown on the web form (reset-password.ts onkeyup); informational, as on the web.
    val hasLower get() = password.any { it.isLowerCase() }
    val hasUpper get() = password.any { it.isUpperCase() }
    val hasDigit get() = password.any { it.isDigit() }
    val hasLength get() = password.length >= 8
}

@HiltViewModel
class ResetPasswordViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val _state = MutableStateFlow(
        ResetUiState(
            email = savedStateHandle.get<String>("email").orEmpty(),
            token = savedStateHandle.get<String>("token").orEmpty(),
        ),
    )
    val state = _state.asStateFlow()

    fun onPassword(v: String) = _state.update { it.copy(password = v) }
    fun onConfirm(v: String) = _state.update { it.copy(confirm = v) }
    fun messageShown() = _state.update { it.copy(message = null) }

    /** Accepts the link from the e-mail: …/reset-password?email=…&token=… */
    fun onResetLink(v: String) {
        val uri = runCatching { Uri.parse(v.trim()) }.getOrNull()
        val email = uri?.getQueryParameter("email").orEmpty()
        val token = uri?.getQueryParameter("token").orEmpty()
        _state.update { it.copy(resetLink = v, email = email.ifBlank { it.email }, token = token.ifBlank { it.token }) }
    }

    fun submit() {
        _state.update { it.copy(submitted = true) }
        val s = _state.value
        if (s.passwordError != null || s.confirmError != null || s.linkError != null || s.isLoading) return
        _state.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            when (val r = authRepository.resetPassword(s.email, s.token, s.password, s.confirm)) {
                is ApiResult.Success -> _state.update {
                    it.copy(isLoading = false, done = r.data.success, message = r.data.message)
                }
                is ApiResult.Failure -> _state.update { it.copy(isLoading = false, message = r.message) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResetPasswordScreen(
    onBack: () -> Unit,
    onDone: (String) -> Unit,
    viewModel: ResetPasswordViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message, state.done) {
        if (state.done) {
            onDone(state.message ?: "Password reset successful")
        } else {
            state.message?.let { snackbar.showSnackbar(it); viewModel.messageShown() }
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reset Password") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (state.email.isBlank() || state.token.isBlank() || state.resetLink.isNotEmpty()) {
                OutlinedTextField(
                    value = state.resetLink,
                    onValueChange = viewModel::onResetLink,
                    label = { Text("Reset link from e-mail *") },
                    isError = state.linkError != null,
                    supportingText = { Text(state.linkError ?: "Long-press the \"Reset Password\" link in the e-mail, copy it and paste here.") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (state.email.isNotBlank()) Text("Account: ${state.email}", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = state.password,
                onValueChange = viewModel::onPassword,
                label = { Text("New Password *") },
                visualTransformation = PasswordVisualTransformation(),
                isError = state.passwordError != null,
                supportingText = state.passwordError?.let { msg -> @Composable { Text(msg) } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Rule("Minimum 8 characters", state.hasLength)
                Rule("At least one lowercase letter (a-z)", state.hasLower)
                Rule("At least one uppercase letter (A-Z)", state.hasUpper)
                Rule("At least one number (0-9)", state.hasDigit)
            }
            OutlinedTextField(
                value = state.confirm,
                onValueChange = viewModel::onConfirm,
                label = { Text("Confirm Password *") },
                visualTransformation = PasswordVisualTransformation(),
                isError = state.confirmError != null,
                supportingText = state.confirmError?.let { msg -> @Composable { Text(msg) } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = viewModel::submit, enabled = !state.isLoading, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                if (state.isLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                else Text("Reset Password")
            }
        }
    }
}

@Composable
private fun Rule(text: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(
            if (ok) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
            contentDescription = null,
            tint = if (ok) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(16.dp),
        )
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

package com.bgauss.dms.data.model

import kotlinx.serialization.Serializable

/** Body of POST api/auth (DMS_BAPL_Data.CustomModel.Login). */
@Serializable
data class LoginRequest(val username: String, val password: String)

/** Body of POST api/auth/location-login (AuthController.LocationLoginRequestModel). */
@Serializable
data class LocationLoginRequest(
    val locationLoginId: String,
    val password: String,
    val locationCode: String? = null,
)

/**
 * Union of the three 200 responses AuthController can return:
 * - regular login (userId, email, userName, dealerCode, employeeCode, mappedZones, lastLoginDate, roles…)
 * - Location Login (employeeId, firstName, lastName, locationCode, locationRoleId…)
 * - multi-location step 1 (requiresLocationSelection, locationLoginId, locations)
 */
@Serializable
data class LoginResponse(
    val status: String? = null,
    val message: String? = null,
    val token: String? = null,
    val userId: String? = null,
    val email: String? = null,
    val userName: String? = null,
    val dealerCode: String? = null,
    val employeeCode: String? = null,
    val mappedZones: String? = null,
    val lastLoginDate: String? = null,
    val role: String? = null,
    val roles: List<String>? = null,
    val compName: String? = null,
    val employeeId: Int? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val locationCode: String? = null,
    val locationRoleId: String? = null,
    val requiresLocationSelection: Boolean = false,
    val locationLoginId: String? = null,
    val locations: List<LocationOption>? = null,
) {
    val isSuccess: Boolean get() = status.equals("success", ignoreCase = true) && !token.isNullOrBlank()
}

@Serializable
data class LocationOption(
    val locationCode: String,
    val locationName: String? = null,
    val city: String? = null,
)

@Serializable
data class ForgotPasswordRequest(val email: String)

@Serializable
data class ResetPasswordRequest(
    val email: String,
    val token: String,
    val password: String,
    val confirmPassword: String,
)

/** `{ success, message, errors? }` returned by forgot/reset password. */
@Serializable
data class SimpleResult(
    val success: Boolean = false,
    val message: String? = null,
    val errors: String? = null,
)

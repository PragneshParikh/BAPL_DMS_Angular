package com.bgauss.dms.core.session

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.bgauss.dms.core.security.TokenCipher
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

private val Context.sessionDataStore: DataStore<Preferences> by preferencesDataStore(name = "bapl_session")

sealed interface SessionState {
    /** Reading the stored session at app start. */
    data object Loading : SessionState
    data object LoggedOut : SessionState
    data class LoggedIn(val session: UserSession) : SessionState
}

/**
 * Single source of truth for the logged-in user. Replaces AuthenticationService +
 * StorageService + TokenStorageService from Angular.
 *
 * - Persists the session encrypted (Keystore AES-GCM) in DataStore.
 * - Starts an expiry timer from the JWT `exp` claim (Angular startTokenTimer) and logs out on expiry.
 * - [onUnauthorized] is called by the OkHttp interceptor on any 401 (Angular ErrorInterceptor).
 */
@Singleton
class SessionManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val cipher: TokenCipher,
    private val json: Json,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val key = stringPreferencesKey("session")

    private val _state = MutableStateFlow<SessionState>(SessionState.Loading)
    val state: StateFlow<SessionState> = _state.asStateFlow()

    private val _logoutMessage = MutableStateFlow<String?>(null)

    /**
     * Reason for the last automatic logout ("Session expired…"), kept until the login screen has
     * shown it ([consumeLogoutMessage]) so it is not lost while navigation switches screens.
     */
    val logoutMessage: StateFlow<String?> = _logoutMessage.asStateFlow()

    fun consumeLogoutMessage() {
        _logoutMessage.value = null
    }

    private var expiryJob: Job? = null

    /** In-memory token for the auth interceptor (no disk read per request). */
    @Volatile
    var currentToken: String? = null
        private set

    init {
        scope.launch { restore() }
    }

    val current: UserSession?
        get() = (state.value as? SessionState.LoggedIn)?.session

    private suspend fun restore() {
        val stored = context.sessionDataStore.data.first()[key]
        val session = stored
            ?.let { cipher.decrypt(it) }
            ?.let { runCatching { json.decodeFromString<UserSession>(it) }.getOrNull() }
        if (session == null || Jwt.isExpired(session.token)) {
            clearStorage()
            publish(null)
        } else {
            publish(session)
        }
    }

    suspend fun start(session: UserSession) {
        persist(session)
        publish(session)
    }

    suspend fun update(transform: (UserSession) -> UserSession) {
        val existing = current ?: return
        val updated = transform(existing)
        persist(updated)
        _state.value = SessionState.LoggedIn(updated)
    }

    fun logout(message: String? = null) {
        scope.launch {
            if (message != null) _logoutMessage.value = message
            clearStorage()
            publish(null)
        }
    }

    fun onUnauthorized() {
        if (current != null) logout("Session expired or invalid token. Please log in again.")
    }

    private suspend fun persist(session: UserSession) {
        val encrypted = cipher.encrypt(json.encodeToString(session))
        context.sessionDataStore.edit { it[key] = encrypted }
    }

    private suspend fun clearStorage() {
        context.sessionDataStore.edit { it.remove(key) }
    }

    private fun publish(session: UserSession?) {
        expiryJob?.cancel()
        currentToken = session?.token
        _state.value = if (session == null) SessionState.LoggedOut else SessionState.LoggedIn(session)
        if (session != null) scheduleExpiry(session.token)
    }

    private fun scheduleExpiry(token: String) {
        val expiry = Jwt.expiryEpochMillis(token)
        if (expiry == null) {
            logout("Invalid session token. Please log in again.")
            return
        }
        expiryJob = scope.launch {
            val wait = expiry - System.currentTimeMillis()
            if (wait > 0) delay(wait)
            logout("Your session has expired. Please log in again.")
        }
    }
}

package com.bgauss.dms.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.data.model.LocationOption
import com.bgauss.dms.data.repository.AuthRepository
import com.bgauss.dms.data.repository.LoginOutcome
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LoginUiState(
    val username: String = "",
    val password: String = "",
    val passwordVisible: Boolean = false,
    val submitted: Boolean = false,
    val isLoading: Boolean = false,
    val locationChoice: LocationChoice? = null,
    val message: String? = null,
) {
    /** login.ts: both fields Validators.required. */
    val usernameError: String? get() = if (submitted && username.isBlank()) "Username is required" else null
    val passwordError: String? get() = if (submitted && password.isEmpty()) "Password is required" else null
}

data class LocationChoice(val locationLoginId: String, val locations: List<LocationOption>, val message: String)

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val authRepository: AuthRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    fun onUsername(v: String) = _state.update { it.copy(username = v) }
    fun onPassword(v: String) = _state.update { it.copy(password = v) }
    fun togglePassword() = _state.update { it.copy(passwordVisible = !it.passwordVisible) }
    fun messageShown() = _state.update { it.copy(message = null) }
    fun dismissLocationChoice() = _state.update { it.copy(locationChoice = null) }

    fun submit() {
        val s = _state.value
        _state.update { it.copy(submitted = true) }
        if (s.username.isBlank() || s.password.isEmpty() || s.isLoading) return
        _state.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            handle(authRepository.login(s.username, s.password))
        }
    }

    /**
     * The API offers a second step for Location Logins linked to several locations
     * (`requiresLocationSelection` → POST auth/location-login with locationCode). The web app
     * only shows a warning at this point; the app lets the user pick the location instead.
     */
    fun chooseLocation(option: LocationOption) {
        val choice = _state.value.locationChoice ?: return
        _state.update { it.copy(isLoading = true, locationChoice = null) }
        viewModelScope.launch {
            handle(authRepository.completeLocationLogin(choice.locationLoginId, _state.value.password, option.locationCode))
        }
    }

    private fun handle(result: ApiResult<LoginOutcome>) {
        when (result) {
            is ApiResult.Failure -> _state.update {
                it.copy(
                    isLoading = false,
                    message = if (result.kind == ApiResult.Kind.Network) result.message
                    else result.message.ifBlank { "An error occurred during login. Please try again." },
                )
            }
            is ApiResult.Success -> when (val outcome = result.data) {
                // Navigation is driven by SessionManager.state; keep the spinner until it switches.
                is LoginOutcome.LoggedIn -> _state.update { it.copy(message = outcome.message) }
                is LoginOutcome.ChooseLocation -> _state.update {
                    it.copy(
                        isLoading = false,
                        locationChoice = LocationChoice(outcome.locationLoginId, outcome.locations, outcome.message),
                    )
                }
                is LoginOutcome.Rejected -> _state.update { it.copy(isLoading = false, message = outcome.message) }
            }
        }
    }
}

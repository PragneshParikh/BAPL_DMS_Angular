package com.bgauss.dms.core.permission

/**
 * Bitmask stored in RoleWiseMenuRight.Permission (DMS_BAPL_Utils.Constants.MenuPermission).
 */
enum class MenuPermission(val bit: Int) {
    View(1),
    Create(2),
    Edit(4),
    Delete(8),
    Download(16),
}

/** One row of `GET /api/role-wise-menu/GetByRoleId` (RoleWiseMenuRight). */
data class MenuRight(val subMenuId: Int, val permission: Int)

/**
 * Same rules as the Angular app, kept in one place:
 *
 * - Page access ([canOpen]) = core/guards/auth.guard.ts
 *   SuperAdmin/Admin open every page; subMenuId 0 is public; otherwise the user needs
 *   a menu-right row for that subMenuId with permission > 0.
 *
 * - Button access ([has]) = core/services/menu-access.service.ts
 *   Bitmask checks apply to the Dealer role only. Every other role has full button access.
 *   A Dealer with no rights configured at all is allowed (fail-open, as in Angular).
 */
class AccessControl(
    role: String?,
    private val rights: List<MenuRight>,
) {
    private val normalizedRole = role.orEmpty().trim().lowercase()

    val isAdmin: Boolean get() = normalizedRole == "superadmin" || normalizedRole == "admin"
    val isSuperAdmin: Boolean get() = normalizedRole == "superadmin"
    val isDealer: Boolean get() = normalizedRole == "dealer"

    fun canOpen(subMenuId: Int?): Boolean {
        if (isAdmin) return true
        if (subMenuId == 0) return true
        if (subMenuId == null) return false
        val right = rights.firstOrNull { it.subMenuId == subMenuId } ?: return false
        return right.permission > 0
    }

    fun has(subMenuId: Int, permission: MenuPermission): Boolean {
        if (!isDealer) return true
        if (rights.isEmpty()) return true
        val match = rights.firstOrNull { it.subMenuId == subMenuId } ?: return false
        return (match.permission and permission.bit) == permission.bit
    }

    fun canView(subMenuId: Int) = has(subMenuId, MenuPermission.View)
    fun canCreate(subMenuId: Int) = has(subMenuId, MenuPermission.Create)
    fun canEdit(subMenuId: Int) = has(subMenuId, MenuPermission.Edit)
    fun canDelete(subMenuId: Int) = has(subMenuId, MenuPermission.Delete)
    fun canDownload(subMenuId: Int) = has(subMenuId, MenuPermission.Download)

    companion object {
        val NONE = AccessControl(null, emptyList())
    }
}

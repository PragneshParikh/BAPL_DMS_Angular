package com.bgauss.dms.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.bgauss.dms.core.permission.AccessControl
import com.bgauss.dms.core.session.UserSession
import com.bgauss.dms.presentation.circular.CircularEditorScreen
import com.bgauss.dms.presentation.circular.CircularPermissionScreen
import com.bgauss.dms.presentation.circular.CircularScreen
import com.bgauss.dms.presentation.dashboard.DashboardScreen
import com.bgauss.dms.presentation.document.PdfViewerScreen
import com.bgauss.dms.presentation.wip.NotConvertedScreen

@Composable
fun HomeNavHost(
    navController: NavHostController,
    access: AccessControl,
    session: UserSession?,
    modifier: Modifier = Modifier,
) {
    NavHost(navController = navController, startDestination = HomeRoutes.DASHBOARD, modifier = modifier) {
        composable(HomeRoutes.DASHBOARD) {
            DashboardScreen(onOpenLink = { link, title -> navController.navigate(RouteRegistry.destinationFor(link, title)) })
        }
        composable(HomeRoutes.CIRCULAR) { entry ->
            CircularScreen(
                access = access,
                onAdd = { navController.navigate(HomeRoutes.circularEditor(null)) },
                onEdit = { id -> navController.navigate(HomeRoutes.circularEditor(id)) },
                onConfigure = { id, title -> navController.navigate(HomeRoutes.circularPermission(id, title)) },
                onOpenPdf = { path, title -> navController.navigate(HomeRoutes.pdfViewer(path, title)) },
                resultFlow = entry.savedStateHandle.getStateFlow(CIRCULAR_SAVED_KEY, ""),
                onResultConsumed = { entry.savedStateHandle[CIRCULAR_SAVED_KEY] = "" },
            )
        }
        composable(
            HomeRoutes.CIRCULAR_EDITOR,
            arguments = listOf(navArgument("id") { type = NavType.IntType; defaultValue = 0 }),
        ) {
            CircularEditorScreen(
                userId = session?.userId.orEmpty(),
                onDone = { message ->
                    navController.previousBackStackEntry?.savedStateHandle?.set(CIRCULAR_SAVED_KEY, message)
                    navController.popBackStack()
                },
                onCancel = { navController.popBackStack() },
            )
        }
        composable(
            HomeRoutes.CIRCULAR_PERMISSION,
            arguments = listOf(
                navArgument("id") { type = NavType.IntType },
                navArgument("title") { type = NavType.StringType; defaultValue = "" },
            ),
        ) {
            CircularPermissionScreen(
                userId = session?.userId.orEmpty(),
                onDone = { message ->
                    navController.previousBackStackEntry?.savedStateHandle?.set(CIRCULAR_SAVED_KEY, message)
                    navController.popBackStack()
                },
                onCancel = { navController.popBackStack() },
            )
        }
        composable(
            HomeRoutes.PDF_VIEWER,
            arguments = listOf(
                navArgument("path") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType; defaultValue = "" },
            ),
        ) { entry ->
            PdfViewerScreen(
                path = entry.arguments?.getString("path").orEmpty(),
                title = entry.arguments?.getString("title").orEmpty(),
            )
        }
        composable(
            HomeRoutes.NOT_CONVERTED,
            arguments = listOf(
                navArgument("link") { type = NavType.StringType; defaultValue = "" },
                navArgument("title") { type = NavType.StringType; defaultValue = "" },
            ),
        ) { entry ->
            NotConvertedScreen(
                link = entry.arguments?.getString("link").orEmpty(),
                title = entry.arguments?.getString("title").orEmpty(),
            )
        }
    }
}

const val CIRCULAR_SAVED_KEY = "circular_result"

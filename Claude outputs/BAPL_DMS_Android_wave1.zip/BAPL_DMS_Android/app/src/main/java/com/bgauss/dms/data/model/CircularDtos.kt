package com.bgauss.dms.data.model

import kotlinx.serialization.Serializable

/**
 * One circular inside the folder tree returned by GET api/circular/GetByDealerCode/{dealerCode}:
 * `{ category: { year: { monthName: { "dd-MM-yyyy": [ CircularItemDto ] } } } }`
 * (CircularService.GetCircularListByDealerCode).
 */
@Serializable
data class CircularItemDto(
    val id: Int = 0,
    val category: String? = null,
    val title: String? = null,
    val description: String? = null,
    val publishDate: String? = null,
    val files: List<CircularFileDto>? = null,
)

/**
 * CircularFileViewModel. `fileData` is the PDF as base64 (System.Text.Json serialises byte[] as base64).
 */
@Serializable
data class CircularFileDto(
    val attachmentId: Int = 0,
    val fileName: String? = null,
    val contentType: String? = null,
    val fileData: String? = null,
    val status: String? = null,
)

typealias CircularFolderTree = Map<String, Map<String, Map<String, Map<String, List<CircularItemDto>>>>>

/** CircularMasterViewModel – GET api/circular/{id}, GET api/circular/GetCircularList, POST/PUT api/circular. */
@Serializable
data class CircularDto(
    val id: Int = 0,
    val category: String? = null,
    val title: String = "",
    val description: String? = null,
    val publishDate: String? = null,
    val expiryDate: String? = null,
    val isActive: Boolean = true,
    val files: List<CircularFileDto>? = null,
    val createdBy: String? = null,
    val createdDate: String? = null,
    val updatedBy: String? = null,
    val updatedDate: String? = null,
)

/**
 * Row of GET api/circular-dealer-assignment/{circularId}: every dealer with `isSelected`
 * for this circular and `areaOfficeId` = zone (see constant.ts zonesData).
 * Also the body item for POST/DELETE …/{circularId}/dealer-permissions (CircularDealerAssignmentViewModel).
 */
@Serializable
data class CircularDealerAssignmentDto(
    val id: Int = 0,
    val circularId: Int = 0,
    val dealerCode: String = "",
    val dealerName: String? = null,
    val areaOfficeId: Int? = null,
    val isSelected: Boolean = false,
    val status: String? = null,
    val createdBy: String? = null,
    val createdDate: String? = null,
    val updatedBy: String? = null,
    val updatedDate: String? = null,
)

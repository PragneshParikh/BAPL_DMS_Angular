package com.bgauss.dms.presentation.document

import android.content.ActivityNotFoundException
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.bgauss.dms.core.util.DocumentFiles
import com.bgauss.dms.presentation.components.EmptyState
import com.bgauss.dms.presentation.components.LoadingState
import com.bgauss.dms.presentation.main.LocalSnackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * In-app PDF preview (replaces `window.open(blobUrl)` in circular.ts viewPdf) using the
 * platform PdfRenderer, plus Save to Downloads / Open with / Share.
 */
@Composable
fun PdfViewerScreen(path: String, title: String) {
    val context = LocalContext.current
    val snackbar = LocalSnackbar.current
    val scope = rememberCoroutineScope()
    val file = remember(path) { File(path) }
    val widthPx = with(LocalDensity.current) { LocalConfiguration.current.screenWidthDp.dp.roundToPx() }

    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val mutex = remember { Mutex() }

    DisposableEffect(path) {
        var fd: ParcelFileDescriptor? = null
        try {
            fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(fd)
        } catch (e: Exception) {
            error = "This file cannot be previewed. Use \"Open with\" to view it in another app."
        }
        onDispose {
            runCatching { renderer?.close() }
            runCatching { fd?.close() }
            renderer = null
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AssistChip(
                onClick = {
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) {
                            runCatching { DocumentFiles.saveToDownloads(context, file, "application/pdf") }.isSuccess
                        }
                        snackbar.showSnackbar(if (ok) "Saved to Downloads/BGauss DMS" else "Could not save the file.")
                    }
                },
                label = { Text("Download") },
                leadingIcon = { Icon(Icons.Outlined.Download, null) },
            )
            AssistChip(
                onClick = {
                    try {
                        context.startActivity(DocumentFiles.viewIntent(DocumentFiles.contentUri(context, file), "application/pdf"))
                    } catch (e: ActivityNotFoundException) {
                        scope.launch { snackbar.showSnackbar("No app found to open PDF files.") }
                    }
                },
                label = { Text("Open with") },
                leadingIcon = { Icon(Icons.Outlined.OpenInNew, null) },
            )
            AssistChip(
                onClick = {
                    context.startActivity(DocumentFiles.shareIntent(DocumentFiles.contentUri(context, file), "application/pdf", title.ifBlank { file.name }))
                },
                label = { Text("Share") },
                leadingIcon = { Icon(Icons.Outlined.Share, null) },
            )
        }
        val r = renderer
        when {
            error != null -> EmptyState(title = "Preview not available", message = error)
            r == null -> LoadingState()
            else -> LazyColumn(
                Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant),
                contentPadding = PaddingValues(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items((0 until r.pageCount).toList()) { index ->
                    val page by produceState<Bitmap?>(null, r, index) {
                        value = withContext(Dispatchers.IO) {
                            mutex.withLock {
                                runCatching {
                                    r.openPage(index).use { p ->
                                        val w = widthPx.coerceAtMost(1600)
                                        val h = (w.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
                                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                        bmp.eraseColor(AndroidColor.WHITE)
                                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                        bmp
                                    }
                                }.getOrNull()
                            }
                        }
                    }
                    val bmp = page
                    if (bmp == null) {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.707f).background(Color.White))
                    } else {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Page ${index + 1}",
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier.fillMaxWidth().background(Color.White),
                        )
                    }
                }
            }
        }
    }
}

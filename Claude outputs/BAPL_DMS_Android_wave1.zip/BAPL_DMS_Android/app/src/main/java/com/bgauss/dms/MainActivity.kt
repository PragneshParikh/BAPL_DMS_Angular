package com.bgauss.dms

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.bgauss.dms.core.session.SessionManager
import com.bgauss.dms.presentation.navigation.AppNavHost
import com.bgauss.dms.presentation.theme.BaplDmsTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var sessionManager: SessionManager

    /** bapldms://reset-password?email=…&token=… handed to the app. */
    private var resetLink by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        resetLink = intent?.resetUri()
        setContent {
            BaplDmsTheme {
                Surface {
                    AppNavHost(sessionManager = sessionManager, resetLink = resetLink)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.resetUri()?.let { resetLink = it }
    }

    private fun Intent.resetUri(): Uri? = data?.takeIf { it.scheme == "bapldms" && it.host == "reset-password" }
}

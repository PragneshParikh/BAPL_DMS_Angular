package com.bgauss.dms.data.repository

import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.network.safeApiCall
import com.bgauss.dms.data.api.ReportApi
import com.bgauss.dms.data.model.JobReportSummaryStats
import com.bgauss.dms.data.model.ModelPivotResponse
import com.bgauss.dms.data.model.TotalSaleDealerWiseResponse
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

/** The four independent results the dashboard loads in parallel (Angular forkJoin). */
data class DashboardData(
    val sale: ApiResult<TotalSaleDealerWiseResponse>,
    val modelSale: ApiResult<ModelPivotResponse>,
    val modelStock: ApiResult<ModelPivotResponse>,
    val jobs: ApiResult<JobReportSummaryStats>,
)

@Singleton
class DashboardRepository @Inject constructor(
    private val reportApi: ReportApi,
) {
    /**
     * Same calls and parameters as components/dashboard/dashboard.ts load():
     * - sale + model-wise sale: fromDate/toDate as yyyy-MM-dd, no dealerCode (the API scopes by token)
     * - model-wise stock: no filters (current stock)
     * - job summary: dealerCode + Date.toISOString(). Angular builds `new Date('yyyy-MM-dd')` for the
     *   start (parsed as UTC midnight) and `new Date('yyyy-MM-ddT23:59:59')` for the end (parsed as local
     *   time), so the same mix is reproduced here to return identical figures.
     */
    suspend fun load(from: LocalDate, to: LocalDate, dealerCode: String): DashboardData = coroutineScope {
        val fromIso = from.format(DateTimeFormatter.ISO_LOCAL_DATE)
        val toIso = to.format(DateTimeFormatter.ISO_LOCAL_DATE)
        val sale = async { safeApiCall { reportApi.totalSaleDealerWise(fromDate = fromIso, toDate = toIso) } }
        val modelSale = async { safeApiCall { reportApi.modelWiseSaleCount(fromDate = fromIso, toDate = toIso) } }
        val modelStock = async { safeApiCall { reportApi.modelWiseStockCount() } }
        val jobs = async {
            safeApiCall {
                reportApi.jobCardSummaryStats(
                    dealerCode = dealerCode,
                    fromDate = from.atStartOfDay(ZoneOffset.UTC).toInstant().toString(),
                    toDate = to.atTime(LocalTime.of(23, 59, 59)).atZone(ZoneId.systemDefault()).toInstant().toString(),
                )
            }
        }
        DashboardData(sale.await(), modelSale.await(), modelStock.await(), jobs.await())
    }
}

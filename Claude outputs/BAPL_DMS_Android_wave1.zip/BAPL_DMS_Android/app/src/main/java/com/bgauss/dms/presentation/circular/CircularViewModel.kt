package com.bgauss.dms.presentation.circular

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.session.SessionManager
import com.bgauss.dms.core.util.DocumentFiles
import com.bgauss.dms.data.model.CircularFileDto
import com.bgauss.dms.data.model.CircularFolderTree
import com.bgauss.dms.data.model.CircularItemDto
import com.bgauss.dms.data.repository.CircularRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/** Selected node path in the Category → Year → Month → Date tree (circular.ts openedX / selectedX fields). */
data class CircularSelection(val category: String, val year: String, val month: String, val date: String)

data class CircularUiState(
    val loading: Boolean = true,
    val error: ApiResult.Failure? = null,
    val tree: CircularFolderTree = emptyMap(),
    val openedCategory: String? = null,
    val openedYear: String? = null,
    val openedMonth: String? = null,
    val selection: CircularSelection? = null,
    val openingFile: Boolean = false,
) {
    val selectedCirculars: List<CircularItemDto>
        get() = selection?.let { tree[it.category]?.get(it.year)?.get(it.month)?.get(it.date) }.orEmpty()
}

sealed interface CircularEvent {
    data class OpenPdf(val path: String, val title: String) : CircularEvent
    data class Message(val text: String) : CircularEvent
}

@HiltViewModel
class CircularViewModel @Inject constructor(
    private val repository: CircularRepository,
    private val sessionManager: SessionManager,
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val _state = MutableStateFlow(CircularUiState())
    val state = _state.asStateFlow()

    private val _events = MutableSharedFlow<CircularEvent>(extraBufferCapacity = 4)
    val events = _events.asSharedFlow()

    init {
        load()
    }

    /** circular.ts getCircular(): keeps the current date selected if it still exists after reload. */
    fun load() {
        val session = sessionManager.current
        val isSuperAdmin = session?.accessControl?.isSuperAdmin == true
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            when (val r = repository.loadTree(isSuperAdmin, session?.effectiveDealerCode.orEmpty())) {
                is ApiResult.Success -> _state.update { s ->
                    val sel = s.selection
                    val stillThere = sel != null && r.data[sel.category]?.get(sel.year)?.get(sel.month)?.get(sel.date) != null
                    s.copy(
                        loading = false,
                        tree = r.data,
                        selection = if (stillThere) sel else null,
                        openedYear = if (stillThere) s.openedYear else null,
                        openedMonth = if (stillThere) s.openedMonth else null,
                    )
                }
                is ApiResult.Failure -> _state.update { it.copy(loading = false, error = r) }
            }
        }
    }

    fun toggleCategory(category: String) = _state.update {
        it.copy(openedCategory = if (it.openedCategory == category) null else category, openedYear = null, openedMonth = null)
    }

    fun toggleYear(year: String) = _state.update {
        it.copy(openedYear = if (it.openedYear == year) null else year, openedMonth = null)
    }

    fun toggleMonth(month: String) = _state.update {
        it.copy(openedMonth = if (it.openedMonth == month) null else month)
    }

    fun selectDate(category: String, year: String, month: String, date: String) = _state.update {
        it.copy(selection = CircularSelection(category, year, month, date))
    }

    fun clearSelection() = _state.update { it.copy(selection = null) }

    /** viewPdf(): decode base64 `fileData` and open the in-app viewer. */
    fun openFile(file: CircularFileDto) {
        val data = file.fileData
        if (data.isNullOrBlank()) {
            _events.tryEmit(CircularEvent.Message("This attachment has no file data."))
            return
        }
        _state.update { it.copy(openingFile = true) }
        viewModelScope.launch {
            val cached = withContext(Dispatchers.IO) {
                runCatching {
                    DocumentFiles.cacheBase64(context, data, file.fileName ?: "circular_${file.attachmentId}.pdf")
                }.getOrNull()
            }
            _state.update { it.copy(openingFile = false) }
            if (cached == null) {
                _events.emit(CircularEvent.Message("Could not open the file."))
            } else {
                _events.emit(CircularEvent.OpenPdf(cached.absolutePath, file.fileName ?: "Circular"))
            }
        }
    }
}

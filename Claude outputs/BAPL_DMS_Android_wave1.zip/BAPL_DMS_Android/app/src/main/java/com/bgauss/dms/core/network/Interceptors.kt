package com.bgauss.dms.core.network

import com.bgauss.dms.core.session.SessionManager
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Adds `Authorization: Bearer <token>` to every request (Angular core/services/auth.interceptor.ts).
 * Login / forgot / reset calls go out without a token simply because none exists yet.
 */
@Singleton
class AuthInterceptor @Inject constructor(
    private val sessionManager: SessionManager,
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = sessionManager.currentToken
        val request = if (token.isNullOrBlank() || chain.request().header(NO_AUTH_HEADER) != null) {
            chain.request().newBuilder().removeHeader(NO_AUTH_HEADER).build()
        } else {
            chain.request().newBuilder().header("Authorization", "Bearer $token").build()
        }
        return chain.proceed(request)
    }

    companion object {
        /** Add this header on a Retrofit method to skip the bearer token (e.g. ERP calls). */
        const val NO_AUTH_HEADER = "X-No-Auth"
    }
}

/**
 * Ends the session on 401 from an authenticated request (Angular core/helpers/error.interceptor.ts).
 * A 401 from the login endpoint itself ("Invalid password.") is left for the screen to show.
 */
@Singleton
class UnauthorizedInterceptor @Inject constructor(
    private val sessionManager: SessionManager,
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val response = chain.proceed(request)
        if (response.code == 401 && request.header("Authorization") != null) {
            sessionManager.onUnauthorized()
        }
        return response
    }
}

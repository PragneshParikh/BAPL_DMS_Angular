package com.bgauss.dms.core.session

import com.bgauss.dms.core.permission.AccessControl
import com.bgauss.dms.core.permission.MenuRight
import kotlinx.serialization.Serializable

/**
 * Everything Angular kept in localStorage after login (currentUser, token, role, dealerCode,
 * locationCode, locationRoleId, selectedModule, menuRights) as one encrypted record.
 */
@Serializable
data class UserSession(
    val token: String,
    val userId: String? = null,
    val email: String? = null,
    val userName: String? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val role: String = "",
    val roles: List<String> = emptyList(),
    val dealerCode: String? = null,
    val employeeCode: String? = null,
    val mappedZones: String? = null,
    val locationCode: String? = null,
    val locationRoleId: String? = null,
    val compName: String? = null,
    val lastLoginDate: String? = null,
    val selectedModule: String = AppModule.ShowRoom.key,
    val menuRights: List<StoredMenuRight> = emptyList(),
) {
    val displayName: String
        get() = listOfNotNull(firstName, lastName).joinToString(" ").ifBlank { userName ?: email ?: "User" }

    val accessControl: AccessControl
        get() = AccessControl(role, menuRights.map { MenuRight(it.subMenuId, it.permission) })

    /**
     * StorageService.getDealerCode(): explicit dealerCode first, then userName.
     * SuperAdmin sessions normally have neither and get an empty string.
     */
    val effectiveDealerCode: String
        get() = dealerCode?.takeIf { it.isNotBlank() } ?: userName.orEmpty()
}

@Serializable
data class StoredMenuRight(val subMenuId: Int, val permission: Int)

/** Top-bar module switch values used by the web app and MenuMaster.ModuleName. */
enum class AppModule(val key: String, val label: String) {
    ShowRoom("ShowRoom", "ShowRoom"),
    WorkShop("WorkShop", "WorkShop"),
    Account("Account", "Account");

    companion object {
        fun fromKey(key: String?): AppModule =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: ShowRoom
    }
}

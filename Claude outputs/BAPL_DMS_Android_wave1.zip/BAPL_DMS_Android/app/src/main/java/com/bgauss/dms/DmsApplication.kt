package com.bgauss.dms

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DmsApplication : Application()

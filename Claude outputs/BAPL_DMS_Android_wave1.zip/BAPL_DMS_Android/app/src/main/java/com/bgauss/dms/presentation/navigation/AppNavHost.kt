package com.bgauss.dms.presentation.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bgauss.dms.core.session.SessionManager
import com.bgauss.dms.core.session.SessionState
import com.bgauss.dms.presentation.auth.ForgotPasswordScreen
import com.bgauss.dms.presentation.auth.LoginScreen
import com.bgauss.dms.presentation.auth.ResetPasswordScreen
import com.bgauss.dms.presentation.components.LoadingState
import com.bgauss.dms.presentation.main.HomeScreen

/**
 * Root navigation. Session state decides between the auth screens and the Home shell,
 * which replaces Angular's AuthGuard redirect to /login.
 */
@Composable
fun AppNavHost(sessionManager: SessionManager, resetLink: Uri?) {
    val sessionState by sessionManager.state.collectAsStateWithLifecycle()
    val navController = rememberNavController()

    if (sessionState is SessionState.Loading) {
        LoadingState()
        return
    }

    val loggedIn = sessionState is SessionState.LoggedIn
    // Fixed for the lifetime of the NavHost; later login/logout transitions are navigations below.
    val startDestination = remember { if (loggedIn) RootRoutes.HOME else RootRoutes.LOGIN }
    LaunchedEffect(loggedIn) {
        val target = if (loggedIn) RootRoutes.HOME else RootRoutes.LOGIN
        val current = navController.currentDestination?.route
        val onAuthScreen = current == RootRoutes.FORGOT || current == RootRoutes.RESET
        if (current != target && !(onAuthScreen && !loggedIn)) {
            navController.navigate(target) { popUpTo(0) { inclusive = true } }
        }
    }
    LaunchedEffect(resetLink) {
        if (resetLink != null && !loggedIn) {
            navController.navigate(RootRoutes.reset(resetLink.getQueryParameter("email"), resetLink.getQueryParameter("token")))
        }
    }

    NavHost(navController = navController, startDestination = startDestination) {
        composable(RootRoutes.LOGIN) {
            LoginScreen(
                logoutMessage = sessionManager.logoutMessage,
                onLogoutMessageShown = sessionManager::consumeLogoutMessage,
                onForgotPassword = { navController.navigate(RootRoutes.FORGOT) },
            )
        }
        composable(RootRoutes.FORGOT) {
            ForgotPasswordScreen(
                onBack = { navController.popBackStack() },
                onHaveResetLink = { navController.navigate(RootRoutes.reset(null, null)) },
            )
        }
        composable(
            RootRoutes.RESET,
            arguments = listOf(
                navArgument("email") { type = NavType.StringType; defaultValue = "" },
                navArgument("token") { type = NavType.StringType; defaultValue = "" },
            ),
        ) {
            ResetPasswordScreen(
                onBack = { navController.popBackStack() },
                onDone = { _ ->
                    // reset-password.ts calls logout() → login page.
                    navController.navigate(RootRoutes.LOGIN) { popUpTo(0) { inclusive = true } }
                },
            )
        }
        composable(RootRoutes.HOME) { HomeScreen() }
    }
}

package com.bgauss.dms.core.network

/**
 * Outcome of one backend call. Screens map this to loading / success / error UI.
 */
sealed interface ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>

    /**
     * @param code HTTP status, or null when the request never reached the server.
     * @param message text safe to show to the user.
     */
    data class Failure(
        val kind: Kind,
        val message: String,
        val code: Int? = null,
    ) : ApiResult<Nothing>

    enum class Kind {
        /** No connectivity, DNS failure, timeout. */
        Network,

        /** 401 – token missing, expired or rejected. Session is cleared by the interceptor. */
        Unauthorized,

        /** 403 – authenticated but not allowed. */
        Forbidden,

        /** Other 4xx – validation/business rule message from the API. */
        Client,

        /** 5xx. */
        Server,

        /** Response could not be parsed. */
        Parse,
    }
}

inline fun <T, R> ApiResult<T>.map(transform: (T) -> R): ApiResult<R> = when (this) {
    is ApiResult.Success -> ApiResult.Success(transform(data))
    is ApiResult.Failure -> this
}

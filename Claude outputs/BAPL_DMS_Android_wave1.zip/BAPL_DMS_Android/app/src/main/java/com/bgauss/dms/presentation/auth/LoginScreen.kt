package com.bgauss.dms.presentation.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bgauss.dms.R
import com.bgauss.dms.presentation.theme.BaplDmsTheme
import com.bgauss.dms.presentation.theme.BrandColors
import kotlinx.coroutines.flow.StateFlow

@Composable
fun LoginScreen(
    logoutMessage: StateFlow<String?>,
    onLogoutMessageShown: () -> Unit,
    onForgotPassword: () -> Unit,
    viewModel: LoginViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.messageShown()
        }
    }
    val pendingLogoutMessage by logoutMessage.collectAsStateWithLifecycle()
    LaunchedEffect(pendingLogoutMessage) {
        pendingLogoutMessage?.let {
            onLogoutMessageShown()
            snackbar.showSnackbar(it)
        }
    }

    // The sign-in card is always light, as on the web, regardless of the system theme.
    BaplDmsTheme(darkTheme = false) {
    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(BrandColors.Navy, Color(0xFF1E3A5F), Color(0xFF2D5580))))
                .padding(padding)
                .imePadding(),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 24.dp)
                    .widthIn(max = 460.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Image(
                            painter = painterResource(R.drawable.bgauss_logo),
                            contentDescription = "BGauss",
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                        )
                        Text(
                            "Dealer Management System",
                            style = MaterialTheme.typography.titleMedium,
                            color = BrandColors.Primary,
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                        )
                        HorizontalDivider()
                        Text("Welcome back", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, color = Color(0xFF111827))
                        Text("Sign in to continue.", style = MaterialTheme.typography.bodyMedium, color = BrandColors.Slate)

                        OutlinedTextField(
                            value = state.username,
                            onValueChange = viewModel::onUsername,
                            label = { Text("Username") },
                            placeholder = { Text("Enter your username") },
                            isError = state.usernameError != null,
                            supportingText = state.usernameError?.let { msg -> @Composable { Text(msg) } },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            value = state.password,
                            onValueChange = viewModel::onPassword,
                            label = { Text("Password") },
                            isError = state.passwordError != null,
                            supportingText = state.passwordError?.let { msg -> @Composable { Text(msg) } },
                            singleLine = true,
                            visualTransformation = if (state.passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = viewModel::togglePassword) {
                                    Icon(
                                        if (state.passwordVisible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                                        contentDescription = if (state.passwordVisible) "Hide password" else "Show password",
                                    )
                                }
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = onForgotPassword) { Text("Forgot password?") }
                        }
                        Button(
                            onClick = viewModel::submit,
                            enabled = !state.isLoading,
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) {
                            if (state.isLoading) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(Modifier.size(8.dp))
                                Text("Signing In...")
                            } else {
                                Text("Sign In")
                            }
                        }
                    }
                }
            }
        }
    }
    }

    state.locationChoice?.let { choice ->
        AlertDialog(
            onDismissRequest = viewModel::dismissLocationChoice,
            title = { Text("Select location") },
            text = {
                Column {
                    Text(choice.message, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    if (choice.locations.isEmpty()) {
                        Text("No locations were returned. Please contact your admin.")
                    }
                    choice.locations.forEach { loc ->
                        ListItem(
                            leadingContent = { Icon(Icons.Outlined.LocationOn, contentDescription = null) },
                            headlineContent = { Text(loc.locationName ?: loc.locationCode) },
                            supportingContent = { Text(listOfNotNull(loc.locationCode, loc.city).joinToString(" · ")) },
                            modifier = Modifier.fillMaxWidth().clickable { viewModel.chooseLocation(loc) },
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = viewModel::dismissLocationChoice) { Text("Cancel") } },
        )
    }
}

package com.bgauss.dms.presentation.wip

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Construction
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bgauss.dms.presentation.navigation.AngularRoutes

/**
 * Shown for menu entries whose web screen has not been converted yet (the Android counterpart of
 * the web app's WorkInProgress route). No data is shown or faked here.
 */
@Composable
fun NotConvertedScreen(link: String, title: String) {
    val route = AngularRoutes.find(link)
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
    ) {
        Icon(Icons.Outlined.Construction, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title.ifBlank { "This screen" }, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(
            "This function is not yet available in the Android app. Please use the DMS web application for now.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
        Text(
            buildString {
                append("Web route: ").append(link.ifBlank { "—" })
                route?.let { append("\nModule: ").append(it.area).append(" · Menu id ").append(it.subMenuId) }
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

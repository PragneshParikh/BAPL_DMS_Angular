package com.bgauss.dms.presentation.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.session.SessionManager
import com.bgauss.dms.core.util.FinancialYear
import com.bgauss.dms.data.model.JobReportSummaryStats
import com.bgauss.dms.data.model.ModelPivotResponse
import com.bgauss.dms.data.model.TotalSaleDealerWiseResponse
import com.bgauss.dms.data.model.TotalSaleDealerWiseRow
import com.bgauss.dms.data.repository.DashboardRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject
import kotlin.math.roundToInt

data class ModelBar(val model: String, val sold: Double, val stock: Double)
data class StockBar(val model: String, val units: Double)

data class DashboardUiState(
    val from: LocalDate = FinancialYear.defaultRange().first,
    val to: LocalDate = FinancialYear.defaultRange().second,
    val loading: Boolean = false,
    val lastUpdated: LocalDateTime? = null,
    val sale: TotalSaleDealerWiseResponse? = null,
    val modelSale: ModelPivotResponse? = null,
    val modelStock: ModelPivotResponse? = null,
    val jobs: JobReportSummaryStats? = null,
    val failedSale: Boolean = false,
    val failedModelSale: Boolean = false,
    val failedStock: Boolean = false,
    val failedJobs: Boolean = false,
    val firstError: ApiResult.Failure? = null,
) {
    // KPI getters – same arithmetic as dashboard.ts.
    val unitsSold: Double? get() = sale?.let { it.grandTotal?.totalUnitsSold ?: 0.0 }
    val salesValue: Double? get() = sale?.let { it.grandTotal?.totalFinalAmount ?: 0.0 }
    val cashCount: Double get() = sale?.grandTotal?.cashCount ?: 0.0
    val creditCount: Double get() = sale?.grandTotal?.creditCount ?: 0.0
    val stockUnits: Double? get() = modelStock?.grandTotal
    val modelCount: Int get() = modelStock?.modelNames?.size ?: 0
    val jobCompletionPct: Int
        get() {
            val total = jobs?.totalJobs ?: 0.0
            return if (total > 0) ((jobs?.completedJobs ?: 0.0) / total * 100).roundToInt() else 0
        }
    val avgTicket: Double?
        get() {
            val u = unitsSold ?: 0.0
            return if (u > 0 && salesValue != null) salesValue!! / u else null
        }

    /** Top 8 dealers by units (dashboard.ts topDealers). */
    val topDealers: List<TotalSaleDealerWiseRow>
        get() = sale?.rows.orEmpty().sortedByDescending { it.totalUnitsSold }.take(8)

    /** buildChartData(): union of sold/stock models, non-zero, sorted by sold then stock, top 10. */
    val salesModels: List<ModelBar>
        get() {
            val sold = modelSale?.columnTotals.orEmpty()
            val stock = modelStock?.columnTotals.orEmpty()
            return (sold.keys + stock.keys).distinct()
                .map { ModelBar(it, sold[it] ?: 0.0, stock[it] ?: 0.0) }
                .filter { it.sold + it.stock > 0 }
                .sortedWith(compareByDescending<ModelBar> { it.sold }.thenByDescending { it.stock })
                .take(10)
        }

    /** Top 6 models by current stock. */
    val stockRows: List<StockBar>
        get() = modelStock?.columnTotals.orEmpty()
            .map { (m, v) -> StockBar(m, v) }
            .filter { it.units > 0 }
            .sortedByDescending { it.units }
            .take(6)
}

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: DashboardRepository,
    private val sessionManager: SessionManager,
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state = _state.asStateFlow()

    init {
        load()
    }

    fun setRange(from: LocalDate, to: LocalDate) {
        if (from.isAfter(to)) return
        _state.update { it.copy(from = from, to = to) }
        load()
    }

    fun load() {
        val s = _state.value
        _state.update { it.copy(loading = true, failedSale = false, failedModelSale = false, failedStock = false, failedJobs = false, firstError = null) }
        viewModelScope.launch {
            val dealerCode = sessionManager.current?.effectiveDealerCode.orEmpty()
            val d = repository.load(s.from, s.to, dealerCode)
            val failures = listOf(d.sale, d.modelSale, d.modelStock, d.jobs).filterIsInstance<ApiResult.Failure>()
            _state.update {
                it.copy(
                    loading = false,
                    lastUpdated = LocalDateTime.now(),
                    sale = (d.sale as? ApiResult.Success)?.data,
                    modelSale = (d.modelSale as? ApiResult.Success)?.data,
                    modelStock = (d.modelStock as? ApiResult.Success)?.data,
                    jobs = (d.jobs as? ApiResult.Success)?.data,
                    failedSale = d.sale is ApiResult.Failure,
                    failedModelSale = d.modelSale is ApiResult.Failure,
                    failedStock = d.modelStock is ApiResult.Failure,
                    failedJobs = d.jobs is ApiResult.Failure,
                    firstError = failures.firstOrNull(),
                )
            }
        }
    }
}

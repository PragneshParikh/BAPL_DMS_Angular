package com.bgauss.dms.presentation.circular

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.data.model.CircularDealerAssignmentDto
import com.bgauss.dms.data.repository.CircularRepository
import com.bgauss.dms.presentation.components.EmptyState
import com.bgauss.dms.presentation.components.ErrorState
import com.bgauss.dms.presentation.components.LoadingState
import com.bgauss.dms.presentation.main.LocalSnackbar
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import javax.inject.Inject

/** constant.ts zonesData – id = DealerMaster.AreaOfficeId. */
data class Zone(val id: Int, val name: String)

val ZONES = listOf(Zone(60, "East"), Zone(63, "West"), Zone(61, "North"), Zone(62, "South"), Zone(59, "Central"))

data class CircularPermissionState(
    val loading: Boolean = true,
    val error: ApiResult.Failure? = null,
    val dealers: List<CircularDealerAssignmentDto> = emptyList(),
    val original: Set<String> = emptySet(),
    val selected: Set<String> = emptySet(),
    val zone: Zone? = null,
    val saving: Boolean = false,
    val message: String? = null,
    val savedMessage: String? = null,
) {
    val zoneDealers: List<CircularDealerAssignmentDto>
        get() = zone?.let { z -> dealers.filter { it.areaOfficeId == z.id } }.orEmpty()
}

@HiltViewModel
class CircularPermissionViewModel @Inject constructor(
    private val repository: CircularRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    val circularId: Int = savedStateHandle.get<Int>("id") ?: 0
    val title: String = savedStateHandle.get<String>("title").orEmpty()

    private val _state = MutableStateFlow(CircularPermissionState())
    val state = _state.asStateFlow()

    init {
        load()
    }

    /** getCircularPermissions(): every dealer with isSelected for this circular. */
    fun load() {
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            when (val r = repository.dealerAssignments(circularId)) {
                is ApiResult.Success -> {
                    val selected = r.data.filter { it.isSelected }.map { it.dealerCode }.toSet()
                    _state.update { it.copy(loading = false, dealers = r.data, original = selected, selected = selected) }
                }
                is ApiResult.Failure -> _state.update { it.copy(loading = false, error = r) }
            }
        }
    }

    fun selectZone(zone: Zone) = _state.update { it.copy(zone = zone) }

    fun toggle(dealerCode: String, checked: Boolean) = _state.update {
        it.copy(selected = if (checked) it.selected + dealerCode else it.selected - dealerCode)
    }

    fun messageShown() = _state.update { it.copy(message = null) }

    /** close(true) + addDealerPermissions / deleteDealerPermissions with the computed difference. */
    fun save(userId: String) {
        val s = _state.value
        if (s.zone == null || s.saving) return
        val now = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
        val byCode = s.dealers.associateBy { it.dealerCode }
        val toAdd = (s.selected - s.original).map { code ->
            CircularDealerAssignmentDto(
                id = 0,
                circularId = circularId,
                dealerCode = code,
                dealerName = byCode[code]?.dealerName,
                isSelected = true,
                createdBy = userId,
                createdDate = now,
            )
        }
        val toDelete = (s.original - s.selected).mapNotNull { code -> byCode[code] }
        if (toAdd.isEmpty() && toDelete.isEmpty()) {
            _state.update { it.copy(savedMessage = "") } // nothing changed: just close, as the web dialog does
            return
        }
        _state.update { it.copy(saving = true) }
        viewModelScope.launch {
            val add = if (toAdd.isNotEmpty()) repository.addDealers(circularId, toAdd) else ApiResult.Success(Unit)
            val del = if (toDelete.isNotEmpty()) repository.removeDealers(circularId, toDelete) else ApiResult.Success(Unit)
            val failure = listOf(add, del).filterIsInstance<ApiResult.Failure>().firstOrNull()
            _state.update {
                if (failure == null) it.copy(saving = false, savedMessage = "Dealer permissions updated successfully.")
                else it.copy(saving = false, message = "Something went wrong while updating dealer permissions.")
            }
        }
    }
}

@Composable
fun CircularPermissionScreen(
    userId: String,
    onDone: (String) -> Unit,
    onCancel: () -> Unit,
    viewModel: CircularPermissionViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    LaunchedEffect(s.message) { s.message?.let { snackbar.showSnackbar(it); viewModel.messageShown() } }
    LaunchedEffect(s.savedMessage) {
        val msg = s.savedMessage ?: return@LaunchedEffect
        if (msg.isEmpty()) onCancel() else onDone(msg)
    }

    when {
        s.loading -> LoadingState()
        s.error != null -> ErrorState(s.error!!, onRetry = viewModel::load)
        else -> Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(viewModel.title.ifBlank { "Circular" }, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Select a zone, then tick the dealers who should see this circular. ${s.selected.size} dealer(s) selected.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ZONES.forEach { z ->
                        FilterChip(selected = s.zone == z, onClick = { viewModel.selectZone(z) }, label = { Text(z.name) })
                    }
                }
            }
            HorizontalDivider()
            when {
                s.zone == null -> EmptyState(title = "Select a zone", modifier = Modifier.weight(1f))
                s.zoneDealers.isEmpty() -> EmptyState(title = "No dealers in this zone", modifier = Modifier.weight(1f))
                else -> LazyColumn(Modifier.weight(1f)) {
                    items(s.zoneDealers, key = { it.dealerCode }) { d ->
                        val checked = d.dealerCode in s.selected
                        Row(
                            Modifier.fillMaxWidth().clickable { viewModel.toggle(d.dealerCode, !checked) }.padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = checked, onCheckedChange = { viewModel.toggle(d.dealerCode, it) })
                            Column {
                                Text(d.dealerName ?: d.dealerCode, style = MaterialTheme.typography.bodyMedium)
                                Text(d.dealerCode, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            HorizontalDivider()
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { viewModel.save(userId) }, enabled = s.zone != null && !s.saving, modifier = Modifier.weight(1f)) {
                    if (s.saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White) else Text("Save")
                }
                OutlinedButton(onClick = onCancel, enabled = !s.saving, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }
    }
}

package com.bgauss.dms.data.repository

import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.network.map
import com.bgauss.dms.core.network.safeApiCall
import com.bgauss.dms.data.api.MenuApi
import com.bgauss.dms.data.model.MenuItemDto
import javax.inject.Inject
import javax.inject.Singleton

/** Sidebar node after normalisation (layouts/sidebar/sidebar.component.ts normalizeMenu). */
data class MenuNode(
    val id: Int,
    val label: String,
    val link: String?,
    val module: String?,
    val children: List<MenuNode> = emptyList(),
) {
    val isGroup: Boolean get() = children.isNotEmpty()
}

@Singleton
class MenuRepository @Inject constructor(
    private val menuApi: MenuApi,
) {
    /** GET api/menu, title rows ("MENU") removed. */
    suspend fun loadMenu(): ApiResult<List<MenuNode>> =
        safeApiCall { menuApi.getMenu() }.map { items -> items.filterNot { it.isTitle }.map { it.toNode() } }

    private fun MenuItemDto.toNode(): MenuNode = MenuNode(
        id = id,
        label = label.orEmpty(),
        link = link?.takeIf { it.isNotBlank() },
        module = module,
        children = subItems.orEmpty().map { it.toNode() },
    )

    companion object {
        /** 'Work Shop', 'work_shop', 'WORKSHOP' -> 'workshop' (sidebar moduleKey). */
        private fun moduleKey(value: String?): String =
            value.orEmpty().lowercase().replace(Regex("[\\s_-]"), "")

        /**
         * Sidebar filterMenuByModule(): children whose module differs from the selected module are
         * hidden, groups left empty are dropped, and a Dashboard entry is added when the menu has none.
         */
        fun filterByModule(menu: List<MenuNode>, module: String): List<MenuNode> {
            val selected = moduleKey(module)
            val filtered = menu.mapNotNull { node ->
                if (node.children.isEmpty()) {
                    node
                } else {
                    val kids = node.children.filter { it.module.isNullOrBlank() || moduleKey(it.module) == selected }
                    if (kids.isEmpty()) null else node.copy(children = kids)
                }
            }
            val hasDashboard = filtered.any { it.link == "/" || it.children.any { c -> c.link == "/" } }
            return if (hasDashboard) filtered else listOf(MenuNode(-1, "Dashboard", "/", null)) + filtered
        }
    }
}

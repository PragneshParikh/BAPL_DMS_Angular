package com.bgauss.dms.data.repository

import com.bgauss.dms.core.network.ApiResult
import com.bgauss.dms.core.network.bodyTextOrThrow
import com.bgauss.dms.core.network.safeApiCall
import com.bgauss.dms.data.api.CircularApi
import com.bgauss.dms.data.model.CircularDealerAssignmentDto
import com.bgauss.dms.data.model.CircularDto
import com.bgauss.dms.data.model.CircularFileDto
import com.bgauss.dms.data.model.CircularFolderTree
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import javax.inject.Inject
import javax.inject.Singleton

/** A PDF picked on the device, already base64-encoded for CircularFileViewModel.FileData. */
data class NewAttachment(val fileName: String, val contentType: String, val base64: String)

/** Editor input (dialogs/add-circular formData). */
data class CircularForm(
    val id: Int = 0,
    val category: String = "Sales",
    val title: String = "",
    val description: String = "",
    val publishDate: LocalDate? = null,
    val expiryDate: String? = null,
    val isActive: Boolean = true,
    val existingFiles: List<CircularFileDto> = emptyList(),
    val removedAttachmentIds: Set<Int> = emptySet(),
    val newFiles: List<NewAttachment> = emptyList(),
    val createdBy: String? = null,
    val createdDate: String? = null,
)

@Singleton
class CircularRepository @Inject constructor(
    private val api: CircularApi,
) {
    private val apiDateTime = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    /**
     * Angular circular.ts: SuperAdmin passes `null` (sent as the literal "null"), everyone else
     * their dealer code; the API then returns only circulars assigned to that dealer.
     */
    suspend fun loadTree(isSuperAdmin: Boolean, dealerCode: String): ApiResult<CircularFolderTree> =
        safeApiCall { api.getFolderTree(if (isSuperAdmin) "null" else dealerCode.ifBlank { "null" }) }

    suspend fun loadAll(): ApiResult<List<CircularDto>> = safeApiCall { api.getCircularList() }

    suspend fun getById(id: Int): ApiResult<CircularDto> = safeApiCall { api.getById(id) }

    /**
     * POST api/circular (new) or PUT api/circular (edit), carrying only Added and Deleted files,
     * as AddCircular.close(true) + Circular.uploadFiles() do.
     *
     * Note: the web dialog uploads through an Azure Blob SAS URL whose upload code is commented out,
     * so new files never reach the API from the browser. The API itself stores `FileData`
     * (CircularController.Create/Update), so the app sends the PDF bytes as base64 in `fileData`.
     */
    suspend fun save(form: CircularForm, userId: String): ApiResult<Unit> = safeApiCall {
        val now = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS).format(apiDateTime)
        val files = form.newFiles.map {
            CircularFileDto(attachmentId = -1, fileName = it.fileName, contentType = it.contentType, fileData = it.base64, status = "Added")
        } + form.existingFiles.filter { it.attachmentId in form.removedAttachmentIds }.map {
            it.copy(fileData = null, status = "Deleted")
        }
        val body = CircularDto(
            id = form.id,
            category = form.category,
            title = form.title.trim(),
            description = form.description.trim(),
            publishDate = form.publishDate?.atStartOfDay()?.format(apiDateTime),
            expiryDate = form.expiryDate,
            isActive = form.isActive,
            files = files,
            createdBy = if (form.id > 0) form.createdBy ?: userId else userId,
            createdDate = if (form.id > 0) form.createdDate ?: now else now,
            updatedBy = if (form.id > 0) userId else null,
            updatedDate = if (form.id > 0) now else null,
        )
        if (form.id > 0) api.update(body).bodyTextOrThrow() else api.create(body).bodyTextOrThrow()
        Unit
    }

    suspend fun dealerAssignments(circularId: Int): ApiResult<List<CircularDealerAssignmentDto>> =
        safeApiCall { api.getDealerAssignments(circularId) }

    suspend fun addDealers(circularId: Int, rows: List<CircularDealerAssignmentDto>): ApiResult<Unit> =
        safeApiCall { api.addDealerPermissions(circularId, rows).bodyTextOrThrow(); Unit }

    suspend fun removeDealers(circularId: Int, rows: List<CircularDealerAssignmentDto>): ApiResult<Unit> =
        safeApiCall { api.deleteDealerPermissions(circularId, rows).bodyTextOrThrow(); Unit }
}

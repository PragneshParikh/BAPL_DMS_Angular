package com.bgauss.dms.presentation.main

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.bgauss.dms.R
import com.bgauss.dms.core.session.AppModule
import com.bgauss.dms.core.util.Formatters
import com.bgauss.dms.data.repository.MenuNode
import com.bgauss.dms.presentation.components.ConfirmDialog
import com.bgauss.dms.presentation.navigation.HomeNavHost
import com.bgauss.dms.presentation.navigation.HomeRoutes
import com.bgauss.dms.presentation.navigation.RouteRegistry
import com.bgauss.dms.presentation.theme.BrandColors
import kotlinx.coroutines.launch

/** App-wide snackbar for screens inside the shell (Angular ToastService). */
val LocalSnackbar = staticCompositionLocalOf<SnackbarHostState> { error("No SnackbarHostState") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navController = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    var confirmLogout by rememberSaveable { mutableStateOf(false) }
    var denied by remember { mutableStateOf<String?>(null) }

    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val title = backStack?.arguments?.getString("title")?.takeIf { it.isNotBlank() }
        ?: titleFor(currentRoute)

    fun openNode(node: MenuNode) {
        val link = node.link ?: return
        val subMenuId = RouteRegistry.subMenuIdFor(link) ?: node.id
        // AuthGuard: no right for this subMenuId → stay where you are.
        if (link != "/" && !state.access.canOpen(subMenuId)) {
            denied = node.label
            return
        }
        val destination = RouteRegistry.destinationFor(link, node.label)
        navController.navigate(destination) {
            popUpTo(HomeRoutes.DASHBOARD) { inclusive = destination == HomeRoutes.DASHBOARD }
            launchSingleTop = true
        }
        scope.launch { drawerState.close() }
    }

    fun switchModule(module: AppModule) {
        if (module == state.module) return
        viewModel.selectModule(module)
        // onSelectionChange(): navigate to dashboard after a module switch.
        navController.navigate(HomeRoutes.DASHBOARD) { popUpTo(HomeRoutes.DASHBOARD) { inclusive = true } }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                DrawerContent(
                    state = state,
                    currentRoute = currentRoute,
                    onModule = ::switchModule,
                    onOpen = ::openNode,
                    onRetry = viewModel::reloadMenu,
                    onLogout = { confirmLogout = true },
                )
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Outlined.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        Text(
                            state.module.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White,
                            modifier = Modifier.padding(end = 4.dp),
                        )
                        IconButton(onClick = { confirmLogout = true }) {
                            Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = "Logout", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = BrandColors.Navy,
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White,
                    ),
                )
            },
            snackbarHost = { SnackbarHost(snackbar) },
        ) { padding ->
            CompositionLocalProvider(LocalSnackbar provides snackbar) {
                HomeNavHost(
                    navController = navController,
                    access = state.access,
                    session = state.session,
                    modifier = Modifier.padding(padding),
                )
            }
        }
    }

    if (confirmLogout) {
        ConfirmDialog(
            title = "Logout",
            message = "Do you want to log out?",
            confirmLabel = "Logout",
            onConfirm = { confirmLogout = false; viewModel.logout() },
            onDismiss = { confirmLogout = false },
        )
    }
    denied?.let { label ->
        AlertDialog(
            onDismissRequest = { denied = null },
            title = { Text("Access denied") },
            text = { Text("You do not have permission to open \"$label\".") },
            confirmButton = { TextButton(onClick = { denied = null }) { Text("OK") } },
        )
    }
}

private fun titleFor(route: String?): String = when (route) {
    HomeRoutes.DASHBOARD, null -> "Dashboard"
    HomeRoutes.CIRCULAR -> "Circular"
    HomeRoutes.CIRCULAR_EDITOR -> "Circular"
    HomeRoutes.CIRCULAR_PERMISSION -> "Circular Permission"
    else -> "BGauss DMS"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DrawerContent(
    state: HomeUiState,
    currentRoute: String?,
    onModule: (AppModule) -> Unit,
    onOpen: (MenuNode) -> Unit,
    onRetry: () -> Unit,
    onLogout: () -> Unit,
) {
    var expanded by rememberSaveable { mutableStateOf(setOf<Int>()) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp)) {
            Image(painterResource(R.drawable.bgauss_logo), contentDescription = "BGauss", modifier = Modifier.height(36.dp))
            Spacer(Modifier.height(12.dp))
            val s = state.session
            Text(s?.displayName ?: "", style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = listOfNotNull(
                s?.role?.takeIf { it.isNotBlank() },
                s?.compName?.takeIf { it.isNotBlank() },
                s?.dealerCode,
                s?.locationCode?.let { "Location $it" },
            ).joinToString(" · ")
            if (sub.isNotBlank()) {
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            s?.lastLoginDate?.let {
                Text("Last login: ${Formatters.apiDateTime(it)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                AppModule.entries.forEachIndexed { i, m ->
                    SegmentedButton(
                        selected = state.module == m,
                        onClick = { onModule(m) },
                        shape = SegmentedButtonDefaults.itemShape(i, AppModule.entries.size),
                    ) { Text(m.label, maxLines = 1) }
                }
            }
        }
        HorizontalDivider()
        when {
            state.menuLoading && state.menu.size <= 1 -> Row(
                Modifier.fillMaxWidth().padding(24.dp),
                horizontalArrangement = Arrangement.Center,
            ) { CircularProgressIndicator(Modifier.size(24.dp)) }

            state.menuError != null && state.menu.size <= 1 -> Column(Modifier.padding(16.dp)) {
                Text(state.menuError.message, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = onRetry) { Text("Retry") }
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(state.menu, key = { it.id }) { node ->
                if (node.isGroup) {
                    val isOpen = node.id in expanded
                    NavigationDrawerItem(
                        label = { Text(node.label) },
                        selected = false,
                        onClick = { expanded = if (isOpen) expanded - node.id else expanded + node.id },
                        badge = { Icon(if (isOpen) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, contentDescription = null) },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    )
                    if (isOpen) {
                        node.children.forEach { child -> MenuLeaf(child, currentRoute, indent = true, onOpen = onOpen) }
                    }
                } else {
                    MenuLeaf(node, currentRoute, indent = false, onOpen = onOpen)
                }
            }
        }
        HorizontalDivider()
        NavigationDrawerItem(
            label = { Text("Logout") },
            icon = { Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = null) },
            selected = false,
            onClick = onLogout,
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun MenuLeaf(node: MenuNode, currentRoute: String?, indent: Boolean, onOpen: (MenuNode) -> Unit) {
    val link = node.link
    val implemented = link != null && RouteRegistry.isImplemented(link)
    val selected = link != null && implemented && RouteRegistry.destinationFor(link, node.label) == currentRoute
    NavigationDrawerItem(
        label = {
            Column {
                Text(node.label)
                if (!implemented) {
                    Text("Web only for now", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        selected = selected,
        onClick = { onOpen(node) },
        modifier = Modifier
            .padding(NavigationDrawerItemDefaults.ItemPadding)
            .padding(start = if (indent) 16.dp else 0.dp),
    )
}

/** Helper for screens: navigate within the shell. */
fun NavHostController.openLink(link: String, title: String) = navigate(RouteRegistry.destinationFor(link, title))

package com.bgauss.dms.data.model

import kotlinx.serialization.Serializable

/**
 * Node of GET api/menu (DMS_BAPL_Data.CustomModel.MenuMasterViewModel).
 * The API already filters children by the caller's role rights; admins get everything.
 * Child `id` is the MenuMaster Id = the `subMenuId` the Angular routes carry in `data`.
 */
@Serializable
data class MenuItemDto(
    val id: Int = 0,
    val label: String? = null,
    val icon: String? = null,
    val isTitle: Boolean = false,
    val isCollapsed: Boolean = false,
    val link: String? = null,
    val parentId: Int? = null,
    val module: String? = null,
    val subItems: List<MenuItemDto>? = null,
)

/** Row of GET api/role-wise-menu/GetByRoleId (DBModels.RoleWiseMenuRight). */
@Serializable
data class RoleWiseMenuRightDto(
    val id: Int = 0,
    val roleId: String? = null,
    val menuId: Int = 0,
    val subMenuId: Int = 0,
    val permission: Int = 0,
)

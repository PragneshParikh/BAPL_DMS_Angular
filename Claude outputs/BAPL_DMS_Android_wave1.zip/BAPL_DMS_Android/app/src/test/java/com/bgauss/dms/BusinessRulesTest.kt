package com.bgauss.dms

import com.bgauss.dms.core.permission.AccessControl
import com.bgauss.dms.core.permission.MenuRight
import com.bgauss.dms.core.session.Jwt
import com.bgauss.dms.core.util.FinancialYear
import com.bgauss.dms.core.util.Formatters
import com.bgauss.dms.data.repository.MenuNode
import com.bgauss.dms.data.repository.MenuRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.util.Base64

/** Parity tests for rules ported from the Angular app (see docs/TESTING.md). */
class BusinessRulesTest {

    // --- auth.guard.ts / menu-access.service.ts -------------------------------------------
    @Test fun dealerGuardAndBitmask() {
        val dealer = AccessControl("Dealer", listOf(MenuRight(53, 1 or 2), MenuRight(27, 0)))
        assertTrue(dealer.canOpen(53))
        assertFalse(dealer.canOpen(27))           // permission 0 → no page access
        assertFalse(dealer.canOpen(99))           // no row → no page access
        assertTrue(dealer.canOpen(0))             // subMenuId 0 is public
        assertTrue(dealer.canCreate(53))
        assertFalse(dealer.canEdit(53))
        assertFalse(dealer.canView(99))
    }

    @Test fun dealerWithoutRightsIsFailOpenForButtonsOnly() {
        val d = AccessControl("Dealer", emptyList())
        assertTrue(d.canDelete(10))
        assertFalse(d.canOpen(10))
    }

    @Test fun adminsAndNonDealers() {
        assertTrue(AccessControl("SuperAdmin", emptyList()).canOpen(140))
        assertTrue(AccessControl("admin", emptyList()).canOpen(1))
        val emp = AccessControl("SalesExecutive", listOf(MenuRight(5, 1)))
        assertTrue(emp.canDelete(5) && emp.canEdit(77))  // bitmask applies to Dealer only
        assertTrue(emp.canOpen(5))
        assertFalse(emp.canOpen(6))
    }

    // --- dashboard-kit.ts num()/inr()/fmtRange()/fyOptions() --------------------------------
    @Test fun indianNumberFormats() {
        assertEquals("12,34,567", Formatters.number(1234567))
        assertEquals("12,34,56,789", Formatters.number(123456789))
        assertEquals("₹2.50 Cr", Formatters.inrCompact(25_000_000.0))
        assertEquals("₹1.50 L", Formatters.inrCompact(150000))
        assertEquals("₹99,999", Formatters.inrCompact(99999))
        assertEquals("₹12,34,567.89", Formatters.inr(1234567.891))
        assertEquals("—", Formatters.number(null))
    }

    @Test fun dates() {
        assertEquals("03.11.2026", Formatters.apiDate("2026-11-03T10:15:00"))
        assertEquals("03.11.2026", Formatters.apiDate("03-11-2026"))
        assertEquals("01.04.2026 – 03.11.2026", Formatters.range(LocalDate.of(2026, 4, 1), LocalDate.of(2026, 11, 3)))
    }

    @Test fun financialYears() {
        val opts = FinancialYear.options(LocalDate.of(2026, 11, 3))
        assertEquals(7, opts.size)
        assertEquals("FY 2026-27", opts.first().label)
        assertEquals(LocalDate.of(2026, 11, 3), opts.first().to)
        assertEquals("FY 2020-21", opts.last().label)
        assertEquals("FY 2025-26", FinancialYear.options(LocalDate.of(2026, 3, 15)).first().label)
    }

    // --- auth.service.ts startTokenTimer() ---------------------------------------------------
    @Test fun jwtExpiry() {
        fun b64(s: String) = Base64.getUrlEncoder().withoutPadding().encodeToString(s.toByteArray())
        val future = System.currentTimeMillis() / 1000 + 3600
        val token = b64("{\"alg\":\"HS256\"}") + "." + b64("{\"exp\":$future}") + ".sig"
        assertEquals(future * 1000, Jwt.expiryEpochMillis(token))
        assertFalse(Jwt.isExpired(token))
        assertTrue(Jwt.isExpired("not-a-jwt"))
        assertTrue(Jwt.isExpired(b64("{}") + "." + b64("{\"exp\":1000}") + ".s"))
    }

    // --- sidebar.component.ts filterMenuByModule() -------------------------------------------
    @Test fun menuFilteredByModuleWithDashboardInjected() {
        val menu = listOf(
            MenuNode(1, "Master", null, null, listOf(
                MenuNode(2, "Color", "/color", "ShowRoom"),
                MenuNode(3, "Job Type", "/job-type-master", "Work Shop"),
            )),
            MenuNode(4, "Services", null, null, listOf(MenuNode(5, "Job Card", "/job-card", "WORKSHOP"))),
            MenuNode(6, "Circular", "/circular", null),
        )
        val showroom = MenuRepository.filterByModule(menu, "ShowRoom")
        assertEquals("Dashboard", showroom.first().label)
        assertEquals(listOf("Dashboard", "Master", "Circular"), showroom.map { it.label })
        assertEquals(listOf("Color"), showroom[1].children.map { it.label })

        val workshop = MenuRepository.filterByModule(menu, "WorkShop")
        assertEquals(listOf("Dashboard", "Master", "Services", "Circular"), workshop.map { it.label })
        assertEquals(listOf("Job Type"), workshop[1].children.map { it.label })
    }
}
